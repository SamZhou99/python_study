/*
Navicat MySQL Data Transfer

Source Server         : localhost-root
Source Server Version : 50505
Source Host           : localhost:3306
Source Database       : yyh_central

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2019-01-11 18:59:53
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `51la`
-- ----------------------------
DROP TABLE IF EXISTS `51la`;
CREATE TABLE `51la` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `domain` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code_pc` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code_m` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `svid_pc` varchar(4) COLLATE utf8mb4_unicode_ci NOT NULL,
  `svid_m` varchar(4) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('1','0') COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of 51la
-- ----------------------------

-- ----------------------------
-- Table structure for `administrator`
-- ----------------------------
DROP TABLE IF EXISTS `administrator`;
CREATE TABLE `administrator` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account` char(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '帳號',
  `name` char(128) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '名稱',
  `description` char(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '描敘',
  `password` char(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '密碼',
  `private_key` char(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '私鑰',
  `remember_token` char(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '紀錄 token',
  `is_2fa` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否開啟二次驗證',
  `is_agent` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否為代理的角色',
  `status` enum('Y','N') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y' COMMENT '狀態 (Y在職/N離職)',
  `last_login` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '最後一次登入',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `account` (`account`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of administrator
-- ----------------------------

-- ----------------------------
-- Table structure for `agent_relation`
-- ----------------------------
DROP TABLE IF EXISTS `agent_relation`;
CREATE TABLE `agent_relation` (
  `admin_id` int(11) NOT NULL,
  `admin_parent_id` int(11) NOT NULL COMMENT '代理的上級內部人員',
  `left` smallint(6) DEFAULT NULL COMMENT '計算代理上下從屬的左節點',
  `right` smallint(6) DEFAULT NULL COMMENT '計算代理上下從屬的右節點',
  `depth` tinyint(4) DEFAULT NULL COMMENT '計算代理上下從屬的深度',
  `note` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '備註'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of agent_relation
-- ----------------------------

-- ----------------------------
-- Table structure for `alternate_url`
-- ----------------------------
DROP TABLE IF EXISTS `alternate_url`;
CREATE TABLE `alternate_url` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection_times` double(8,2) NOT NULL,
  `status` enum('1','0') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of alternate_url
-- ----------------------------

-- ----------------------------
-- Table structure for `announcement`
-- ----------------------------
DROP TABLE IF EXISTS `announcement`;
CREATE TABLE `announcement` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `announcement` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(2083) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('1','0') COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `kind` enum('all','pc','mobile','app') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `theme_id` int(10) unsigned NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `announcement_theme_id_index` (`theme_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of announcement
-- ----------------------------

-- ----------------------------
-- Table structure for `banner`
-- ----------------------------
DROP TABLE IF EXISTS `banner`;
CREATE TABLE `banner` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `color` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `login` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `status` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `device` enum('pc','mobile') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `theme_id` int(10) unsigned NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `begin_time` datetime DEFAULT NULL,
  `finish_time` datetime DEFAULT NULL,
  `odr_num` smallint(6) NOT NULL DEFAULT 999 COMMENT '排序, 數字大的排在上面',
  PRIMARY KEY (`id`),
  KEY `banner_theme_id_index` (`theme_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of banner
-- ----------------------------

-- ----------------------------
-- Table structure for `channel_category`
-- ----------------------------
DROP TABLE IF EXISTS `channel_category`;
CREATE TABLE `channel_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of channel_category
-- ----------------------------

-- ----------------------------
-- Table structure for `cnzz`
-- ----------------------------
DROP TABLE IF EXISTS `cnzz`;
CREATE TABLE `cnzz` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `domain` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code_pc` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code_m` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('1','0') COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of cnzz
-- ----------------------------

-- ----------------------------
-- Table structure for `domain`
-- ----------------------------
DROP TABLE IF EXISTS `domain`;
CREATE TABLE `domain` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `domain` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `domain` (`domain`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of domain
-- ----------------------------

-- ----------------------------
-- Table structure for `events`
-- ----------------------------
DROP TABLE IF EXISTS `events`;
CREATE TABLE `events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '標題',
  `start_time` datetime NOT NULL COMMENT '開始時間',
  `end_time` datetime NOT NULL COMMENT '結束時間',
  `desc` text COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '大綱',
  `content` text COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '內文',
  `apply_request` char(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '申請要求',
  `bet_amount_multiple` tinyint(1) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '狀態',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `online_time` datetime NOT NULL COMMENT '上線時間',
  `cover_image_pc` char(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'pc封面圖',
  `cover_image_mobile` char(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'monile封面圖',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `odr_num` smallint(6) NOT NULL DEFAULT 0 COMMENT '排序, 數字小的排在上面',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of events
-- ----------------------------

-- ----------------------------
-- Table structure for `events_buttons`
-- ----------------------------
DROP TABLE IF EXISTS `events_buttons`;
CREATE TABLE `events_buttons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `is_login` tinyint(1) NOT NULL DEFAULT 1 COMMENT '需要登入',
  `outside_link` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_id` int(10) unsigned NOT NULL COMMENT '活動id',
  `game_id` int(11) NOT NULL DEFAULT 0 COMMENT '遊戲id',
  `customer_service` tinyint(1) NOT NULL DEFAULT 0 COMMENT '連至客服',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `name` char(16) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '名稱',
  `deposit` tinyint(1) NOT NULL COMMENT '去存款',
  `game_category_id` int(10) unsigned NOT NULL COMMENT '前端頁面的遊戲bar類別''',
  `inner_link` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '內部連結',
  PRIMARY KEY (`id`),
  KEY `events_buttons_event_id_foreign` (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of events_buttons
-- ----------------------------

-- ----------------------------
-- Table structure for `events_category`
-- ----------------------------
DROP TABLE IF EXISTS `events_category`;
CREATE TABLE `events_category` (
  `category_id` int(10) unsigned NOT NULL COMMENT '對應遊戲種類id',
  `event_id` int(10) unsigned NOT NULL COMMENT '對應活動id',
  KEY `events_category_category_id_foreign` (`category_id`),
  KEY `events_category_event_id_foreign` (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of events_category
-- ----------------------------

-- ----------------------------
-- Table structure for `game_category`
-- ----------------------------
DROP TABLE IF EXISTS `game_category`;
CREATE TABLE `game_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` char(16) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '代號',
  `name` char(16) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '名稱',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of game_category
-- ----------------------------
INSERT INTO `game_category` VALUES ('1', 'video', '真人', null, null, null);
INSERT INTO `game_category` VALUES ('2', 'slot', '電子', null, null, null);
INSERT INTO `game_category` VALUES ('3', 'sport', '體育', null, null, null);
INSERT INTO `game_category` VALUES ('4', 'lotto', '彩票', null, null, null);
INSERT INTO `game_category` VALUES ('5', 'chess', '棋牌', null, null, null);
INSERT INTO `game_category` VALUES ('6', 'other', '其他', null, null, null);
INSERT INTO `game_category` VALUES ('7', 'hunter', '捕魚', null, null, null);

-- ----------------------------
-- Table structure for `game_list`
-- ----------------------------
DROP TABLE IF EXISTS `game_list`;
CREATE TABLE `game_list` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gametype` char(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `platformid` int(10) unsigned NOT NULL,
  `group` enum('VIDEO','SLOTS','LOTTERY','SPORTS','POKER','') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cate` enum('CLASSIC','JACKPOT','DESKTOP','VIDEO_POKER','OTHER','MULTIPLAYER') COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('Y','N') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `newest` enum('Y','N') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `pc` tinyint(1) NOT NULL DEFAULT 1,
  `mobile` tinyint(1) NOT NULL DEFAULT 1,
  `popular` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否熱門',
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_num` smallint(6) NOT NULL DEFAULT 99,
  `category_id` int(10) unsigned NOT NULL DEFAULT 1,
  `sub_category_id` int(10) unsigned NOT NULL DEFAULT 1,
  `platform_id` int(10) unsigned NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `game_list_platformid_foreign` (`platformid`),
  KEY `game_list_category_id_foreign` (`category_id`),
  KEY `game_list_sub_category_id_foreign` (`sub_category_id`),
  KEY `game_list_platform_id_foreign` (`platform_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of game_list
-- ----------------------------
INSERT INTO `game_list` VALUES ('1', '日本武士', '513', '1', null, 'CLASSIC', 'N', 'N', null, null, '1', '1', '0', '/frontend/img/slots/平台1號/1529377580.jpg', '99', '2', '1', '1');
INSERT INTO `game_list` VALUES ('2', 'eBET大廳', '0', '2', null, 'OTHER', 'N', 'N', null, null, '1', '1', '0', '', '99', '6', '5', '2');
INSERT INTO `game_list` VALUES ('3', '糖果派对', '5902', '3', null, 'CLASSIC', 'N', 'Y', null, null, '1', '1', '0', '/frontend/img/slots/平台3號/1529382471.jpg', '99', '2', '1', '3');
INSERT INTO `game_list` VALUES ('4', 'Allbet大廳', '0', '4', null, 'OTHER', 'N', 'N', null, null, '1', '1', '0', '', '99', '6', '5', '4');
INSERT INTO `game_list` VALUES ('5', '开心假期', 'er', '5', null, 'CLASSIC', 'N', 'N', null, null, '1', '0', '0', '/frontend/img/slots/pt/er.jpg', '99', '2', '1', '5');
INSERT INTO `game_list` VALUES ('6', '沙巴大廳', '0', '6', null, 'OTHER', 'N', 'N', null, null, '1', '1', '0', '', '99', '6', '5', '6');
INSERT INTO `game_list` VALUES ('7', '雲谷大廳', '0', '7', null, 'OTHER', 'N', 'N', null, null, '1', '1', '0', '', '99', '6', '6', '7');
INSERT INTO `game_list` VALUES ('8', '奔驰宝马', 'YP802', '8', null, 'OTHER', 'N', 'N', null, null, '1', '1', '0', '/frontend/img/slots/yoplay/YP802.jpg', '99', '2', '5', '8');
INSERT INTO `game_list` VALUES ('9', '棋牌大廳', '0', '9', null, 'OTHER', 'N', 'N', null, null, '1', '1', '0', '', '99', '6', '5', '9');
INSERT INTO `game_list` VALUES ('10', '巨奖厅', '800', '10', null, 'JACKPOT', 'N', 'Y', null, null, '1', '1', '0', '/frontend/img/slots/平台10號/1529392065.jpg', '99', '2', '2', '10');
INSERT INTO `game_list` VALUES ('11', 'HG大廳', '0', '11', null, 'OTHER', 'N', 'N', null, null, '1', '1', '0', '', '99', '6', '5', '11');
INSERT INTO `game_list` VALUES ('12', '拉斯维加斯之夜', 'slot', '12', null, 'CLASSIC', 'N', 'N', null, null, '1', '0', '0', '/frontend/img/slots/平台12號/1520393698.jpg', '99', '2', '1', '12');
INSERT INTO `game_list` VALUES ('13', '糖果碰碰乐', '544', '1', null, 'CLASSIC', 'N', 'N', null, null, '1', '0', '0', '/frontend/img/slots/平台1號/1529377567.jpg', '99', '2', '1', '13');

-- ----------------------------
-- Table structure for `game_platform`
-- ----------------------------
DROP TABLE IF EXISTS `game_platform`;
CREATE TABLE `game_platform` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `display_name` char(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` char(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_master` tinyint(4) NOT NULL,
  `status` enum('Y','N') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `ucid` int(10) unsigned NOT NULL,
  `lobbyid` char(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `trialgold` int(10) unsigned NOT NULL,
  `order_num` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of game_platform
-- ----------------------------
INSERT INTO `game_platform` VALUES ('1', 'AG国际厅', 'agin', '1', 'Y', '13', '', '500', '1', null, null, null);
INSERT INTO `game_platform` VALUES ('2', 'ebet厅', 'ebet', '1', 'Y', '21', '', '1000', '2', null, null, null);
INSERT INTO `game_platform` VALUES ('3', 'BBIN厅', 'bbin', '1', 'Y', '14', '', '0', '6', null, null, null);
INSERT INTO `game_platform` VALUES ('4', '欧博厅', 'allbet', '1', 'Y', '18', '', '0', '3', null, null, null);
INSERT INTO `game_platform` VALUES ('5', 'PT厅', 'pt', '1', 'Y', '16', '', '0', '99', null, null, null);
INSERT INTO `game_platform` VALUES ('6', '沙巴体育', 'saba', '1', 'Y', '19', '', '0', '4', null, null, null);
INSERT INTO `game_platform` VALUES ('7', '彩票厅', 'onegood', '1', 'Y', '17', '', '2000', '7', null, null, null);
INSERT INTO `game_platform` VALUES ('8', 'YoPlay电玩', 'yoplay', '0', 'Y', '13', 'YP800', '500', '5', null, null, null);
INSERT INTO `game_platform` VALUES ('9', '棋牌游戏', 'poker', '0', 'N', '13', '', '0', '99', null, null, null);
INSERT INTO `game_platform` VALUES ('10', '巨奖厅', 'jackpot', '0', 'Y', '13', '800', '0', '8', null, null, null);
INSERT INTO `game_platform` VALUES ('11', 'AG旗舰厅', 'ag', '1', 'Y', '11', '', '2000', '1', null, null, null);
INSERT INTO `game_platform` VALUES ('12', 'HG', 'hg', '1', 'Y', '12', '', '500', '0', null, null, null);
INSERT INTO `game_platform` VALUES ('13', 'XIN厅', 'xin', '0', 'Y', '13', '500', '0', '0', null, null, null);
INSERT INTO `game_platform` VALUES ('14', 'padding', 'padding', '0', 'N', '99', '', '0', '0', null, null, '2019-01-11 16:41:58');
INSERT INTO `game_platform` VALUES ('15', 'OG厅', 'og', '1', 'Y', '22', '', '0', '0', null, null, null);

-- ----------------------------
-- Table structure for `game_sub_category`
-- ----------------------------
DROP TABLE IF EXISTS `game_sub_category`;
CREATE TABLE `game_sub_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` char(16) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '代號',
  `name` char(16) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '名稱',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of game_sub_category
-- ----------------------------
INSERT INTO `game_sub_category` VALUES ('1', 'classic', '经典游戏', null, null, null);
INSERT INTO `game_sub_category` VALUES ('2', 'jackpot', '大奖老虎机', null, null, null);
INSERT INTO `game_sub_category` VALUES ('3', 'desktop', '桌面游戏', null, null, null);
INSERT INTO `game_sub_category` VALUES ('4', 'video_poker', '视频扑克', null, null, null);
INSERT INTO `game_sub_category` VALUES ('5', 'other', '其他游戏', null, null, null);
INSERT INTO `game_sub_category` VALUES ('6', 'multiplayer', '多人模式', null, null, null);

-- ----------------------------
-- Table structure for `jobs`
-- ----------------------------
DROP TABLE IF EXISTS `jobs`;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint(1) NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_reserved_at_index` (`queue`,`reserved_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of jobs
-- ----------------------------

-- ----------------------------
-- Table structure for `message_members`
-- ----------------------------
DROP TABLE IF EXISTS `message_members`;
CREATE TABLE `message_members` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `member` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '會員account',
  `member_id` int(11) NOT NULL,
  `message_text_id` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '0=>未讀, 1=>已讀',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of message_members
-- ----------------------------

-- ----------------------------
-- Table structure for `message_texts`
-- ----------------------------
DROP TABLE IF EXISTS `message_texts`;
CREATE TABLE `message_texts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '訊息內容',
  `admin_id` int(11) NOT NULL COMMENT '發送者',
  `type` tinyint(3) unsigned NOT NULL COMMENT '1=>public(全站), 2=>group(指定部分會員), 3=>private(指定單一會員)',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `expired_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of message_texts
-- ----------------------------

-- ----------------------------
-- Table structure for `migrations`
-- ----------------------------
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=261 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of migrations
-- ----------------------------
INSERT INTO `migrations` VALUES ('196', '2018_06_28_175404_create_51la_table', '1');
INSERT INTO `migrations` VALUES ('197', '2018_06_28_175404_create_alternate_url_table', '1');
INSERT INTO `migrations` VALUES ('198', '2018_06_28_175404_create_announcement_table', '1');
INSERT INTO `migrations` VALUES ('199', '2018_06_28_175404_create_banner_table', '1');
INSERT INTO `migrations` VALUES ('200', '2018_06_28_175404_create_cnzz_table', '1');
INSERT INTO `migrations` VALUES ('201', '2018_06_28_175404_create_events_buttons_table', '1');
INSERT INTO `migrations` VALUES ('202', '2018_06_28_175404_create_events_category_table', '1');
INSERT INTO `migrations` VALUES ('203', '2018_06_28_175404_create_events_table', '1');
INSERT INTO `migrations` VALUES ('204', '2018_06_28_175404_create_game_category_table', '1');
INSERT INTO `migrations` VALUES ('205', '2018_06_28_175404_create_game_list_table', '1');
INSERT INTO `migrations` VALUES ('206', '2018_06_28_175404_create_game_platform_table', '1');
INSERT INTO `migrations` VALUES ('207', '2018_06_28_175404_create_game_sub_category_table', '1');
INSERT INTO `migrations` VALUES ('208', '2018_06_28_175404_create_jobs_table', '1');
INSERT INTO `migrations` VALUES ('209', '2018_06_28_175404_create_reg_ip_table', '1');
INSERT INTO `migrations` VALUES ('210', '2018_06_28_175404_create_setting_table', '1');
INSERT INTO `migrations` VALUES ('211', '2018_06_28_175404_create_theme_website_table', '1');
INSERT INTO `migrations` VALUES ('212', '2018_06_28_175404_create_themes_table', '1');
INSERT INTO `migrations` VALUES ('213', '2018_06_28_175404_create_white_list_table', '1');
INSERT INTO `migrations` VALUES ('214', '2018_06_29_150207_create_channel_browse_data_table', '1');
INSERT INTO `migrations` VALUES ('215', '2018_06_29_150207_create_channel_overview_data_table', '1');
INSERT INTO `migrations` VALUES ('216', '2018_06_29_150207_create_channel_overview_table', '1');
INSERT INTO `migrations` VALUES ('217', '2018_06_29_150207_create_member_balance_list_table', '1');
INSERT INTO `migrations` VALUES ('218', '2018_06_29_150207_create_member_bet_list_table', '1');
INSERT INTO `migrations` VALUES ('219', '2018_06_29_150207_create_member_bonus_list_table', '1');
INSERT INTO `migrations` VALUES ('220', '2018_06_29_150207_create_member_info_list_table', '1');
INSERT INTO `migrations` VALUES ('221', '2018_06_29_150207_create_member_summary_related_fingerprint_table', '1');
INSERT INTO `migrations` VALUES ('222', '2018_06_29_150207_create_member_summary_related_ip_table', '1');
INSERT INTO `migrations` VALUES ('223', '2018_06_29_150207_create_system_operation_table', '1');
INSERT INTO `migrations` VALUES ('224', '2018_06_30_143339_create_pcode_table', '1');
INSERT INTO `migrations` VALUES ('225', '2018_06_30_143830_create_pcode_domain_table', '1');
INSERT INTO `migrations` VALUES ('226', '2018_06_30_154641_create_channel_category_table', '1');
INSERT INTO `migrations` VALUES ('227', '2018_07_16_150000_create_statisticable_record_table', '1');
INSERT INTO `migrations` VALUES ('228', '2018_07_24_111057_create_pcode_overview_table', '1');
INSERT INTO `migrations` VALUES ('229', '2018_08_02_181543_create_banks_table', '1');
INSERT INTO `migrations` VALUES ('230', '2018_08_02_181605_create_bank_cards_table', '1');
INSERT INTO `migrations` VALUES ('231', '2018_08_03_121424_create_tm_reason', '1');
INSERT INTO `migrations` VALUES ('232', '2018_08_03_121526_create_tm_result', '1');
INSERT INTO `migrations` VALUES ('233', '2018_08_03_163605_create_tm_task', '1');
INSERT INTO `migrations` VALUES ('234', '2018_08_03_175956_create_tm_telephone', '1');
INSERT INTO `migrations` VALUES ('235', '2018_08_03_180753_create_payment_fee_table', '1');
INSERT INTO `migrations` VALUES ('236', '2018_08_03_181950_create_tm_task_telephone', '1');
INSERT INTO `migrations` VALUES ('237', '2018_08_03_182042_create_tm_telephone_member_relation', '1');
INSERT INTO `migrations` VALUES ('238', '2018_08_03_182155_create_tm_voip_log', '1');
INSERT INTO `migrations` VALUES ('239', '2018_08_11_123411_create_bet_history_table', '1');
INSERT INTO `migrations` VALUES ('240', '2018_08_21_155724_create_tm_telephone_upload_log', '1');
INSERT INTO `migrations` VALUES ('241', '2018_08_21_160326_create_tm_telephone_other_info', '1');
INSERT INTO `migrations` VALUES ('242', '2018_09_05_143830_create_domain_table', '1');
INSERT INTO `migrations` VALUES ('243', '2018_09_05_151806_create_tm_admin_extra_info', '1');
INSERT INTO `migrations` VALUES ('244', '2018_09_05_152116_create_tm_voip_log_inspection', '1');
INSERT INTO `migrations` VALUES ('245', '2018_09_19_103424_create_sms_log', '1');
INSERT INTO `migrations` VALUES ('246', '2018_09_19_104001_create_sms_template', '1');
INSERT INTO `migrations` VALUES ('247', '2018_09_26_115735_create_message_members_table', '1');
INSERT INTO `migrations` VALUES ('248', '2018_09_26_115816_create_message_texts_table', '1');
INSERT INTO `migrations` VALUES ('249', '2018_09_28_032942_create_sms_account', '1');
INSERT INTO `migrations` VALUES ('250', '2018_10_24_105141_create_telephoneTaskMaintain', '1');
INSERT INTO `migrations` VALUES ('251', '2018_10_24_113726_create_provider_telephone_support', '1');
INSERT INTO `migrations` VALUES ('252', '2018_11_02_180706_create_tm_voip_provider', '1');
INSERT INTO `migrations` VALUES ('253', '2018_12_06_152446_create_agent_relation_table', '1');
INSERT INTO `migrations` VALUES ('254', '2018_12_06_175404_create_administrator_table', '1');
INSERT INTO `migrations` VALUES ('255', '2018_12_06_175404_create_permission_role_table', '1');
INSERT INTO `migrations` VALUES ('256', '2018_12_06_175404_create_permissions_table', '1');
INSERT INTO `migrations` VALUES ('257', '2018_12_06_175404_create_role_user_table', '1');
INSERT INTO `migrations` VALUES ('258', '2018_12_06_175404_create_roles_table', '1');
INSERT INTO `migrations` VALUES ('259', '2019_01_08_163925_create_tm_voip_log_tm_task_relation', '1');
INSERT INTO `migrations` VALUES ('260', '2019_01_08_170224_create_tm_telephone_admin_relation', '1');

-- ----------------------------
-- Table structure for `pcode`
-- ----------------------------
DROP TABLE IF EXISTS `pcode`;
CREATE TABLE `pcode` (
  `pcode` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `promoter_id` int(11) NOT NULL,
  `channel_category_id` tinyint(3) unsigned DEFAULT NULL,
  `commission_id` tinyint(4) NOT NULL DEFAULT 0,
  `bank_group` tinyint(4) NOT NULL DEFAULT 0,
  `bonus_switch` tinyint(4) NOT NULL DEFAULT 1,
  `deposit_bonus_switch` tinyint(4) NOT NULL DEFAULT 1,
  `auto_withdrawal` tinyint(4) NOT NULL DEFAULT 1,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`pcode`)
) ENGINE=InnoDB AUTO_INCREMENT=100001 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of pcode
-- ----------------------------

-- ----------------------------
-- Table structure for `pcode_domain`
-- ----------------------------
DROP TABLE IF EXISTS `pcode_domain`;
CREATE TABLE `pcode_domain` (
  `pcode` int(10) unsigned NOT NULL,
  `domain_id` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of pcode_domain
-- ----------------------------

-- ----------------------------
-- Table structure for `permissions`
-- ----------------------------
DROP TABLE IF EXISTS `permissions`;
CREATE TABLE `permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '權限英文名稱',
  `display_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '權限中文描敘',
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '權限細節描述',
  `group` char(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '權限組別',
  `category` enum('PAGE','API','ACTION','REPORT_COLUMN','REPORT_SCOPE','OTHER') COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '權限分類，有PAGE，API，ACTION，REPORT_COLUMN，REPORT_SCOPE',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=145 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of permissions
-- ----------------------------
INSERT INTO `permissions` VALUES ('1', 'sidebar-fronted-setting-group', '前端推廣選單', 'can see fronted setting sidebar group', 'fronted-setting', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('2', 'sidebar-channel-management-group', '渠道管理選單', 'can see fronted setting sidebar group', 'channel-management', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('3', 'sidebar-member-management-group', '用戶管理選單', 'can see member management sidebar group', 'member-management', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('4', 'page-announcement', '公告管理', 'enter announcement page', 'fronted-setting', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('5', 'page-statistics', '統計代碼', 'enter Statistics page', 'fronted-setting', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('6', 'page-alternate', '備用域名', 'enter Alternate page', 'fronted-setting', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('7', 'page-setting', '系統設定', 'enter fornted System Setting page', 'fronted-setting', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('8', 'page-channel-promoter-pcode-report', '行銷pcode成效', 'enter channel effectiveness', 'channel-management', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('9', 'page-channel-owner-effectiveness', '行銷成效', 'enter channel effectiveness', 'channel-management', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('10', 'page-channel-effectiveness', '渠道成效', 'enter channel effectiveness', 'channel-management', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('11', 'page-channel-pcode-report', '推廣碼成效', '推廣碼成效', 'channel-management', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('12', 'page-channel-pcode', '渠道列表', 'enter channel domain', 'channel-management', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('13', 'page-channel-group', '渠道分類', 'enter channel group', 'channel-management', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('14', 'page-channel-owner', '行銷列表', 'enter channel owner', 'channel-management', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('15', 'page-channel-browse-data', '域名瀏覽資料', 'enter channel browse data', 'channel-management', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('16', 'page-channel-agent', '代理列表', '代理列表', 'channel-management', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('17', 'page-tester', 'Page tester', 'enter tester', '', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('18', 'sidebar-central-management-group', '後台管理選單', 'can see member management sidebar group', 'central-management', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('19', 'page-central-user', '後台使用者管理', 'enter central user', 'central-management', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('20', 'page-central-role', '後台角色設定', 'enter central role', 'central-management', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('21', 'reg_pc_person', 'pc注册', 'can see channel effectiveness reg_count_people column', 'channel_effectiveness', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('22', 'first_deposit_person', '首存人数', 'can see channel effectiveness first_deposit_count_people column', 'channel_effectiveness', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('23', 'deposit_percentage', '注转率', 'can see channel effectiveness deposit_percentage column', 'channel_effectiveness', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('24', 'deposit_times_2down', '存款≤2次', 'can see channel effectiveness deposit_times_2down column', 'channel_effectiveness', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('25', 'deposit_times_3-5', '存款3-5次', '存款3-5次', 'channel_effectiveness', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('26', 'deposit_times_6-9', '存款6-9次', '存款6-9次', 'channel_effectiveness', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('27', 'deposit_times_10up', '存款10次以上', '存款10次以上', 'channel_effectiveness', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('28', 'first_deposit_amount', '累计首存金额', 'can see channel effectiveness first_deposit_sum_money column', 'channel_effectiveness', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('29', 'deposit_amount', '累计存款', 'can see channel effectiveness deposit_sum_money column', 'channel_effectiveness', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('30', 'withdrawal_amount', '取款总额', 'can see channel effectiveness withdrawals_sum_money column', 'channel_effectiveness', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('31', 'bet_valid_amount', '总投注码量', 'can see channel effectiveness realamount_sum_money column', 'channel_effectiveness', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('32', 'result_amount', '总累计输赢', 'can see channel effectiveness uresult_sum column', 'channel_effectiveness', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('33', 'online_person', '总活跃人数', 'can see channel effectiveness user_count column', 'channel_effectiveness', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('34', 'online_person_sum', '总活跃天数', 'can see channel effectiveness report_count column', 'channel_effectiveness', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('35', 'average_days', '平均活跃天数', 'can see channel effectiveness average_days column', 'channel_effectiveness', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('36', 'bonus_normal', '一般贈金', 'can see channel effectiveness bonus column', 'channel_effectiveness', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('37', 'bonus_topic', '活動贈金', 'can see channel effectiveness integral column', 'channel_effectiveness', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('38', 'bonus_take_off', '贈金扣除', '', 'channel_effectiveness', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('39', 'rake_back', '返水', 'can see channel effectiveness return_water column', 'channel_effectiveness', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('40', 'cost', '花費', 'can see channel effectiveness cost column', 'channel_effectiveness', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('41', 'net_profit', '淨盈利', 'can see channel effectiveness net_profit column', 'channel_effectiveness', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('42', 'average_deposit_amount', '平均首存金额', 'can see channel effectiveness average_deposit_sum_money column', 'channel_effectiveness', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('43', 'deposit_personal', '总存款', 'can see channel effectiveness deposit_personal column', 'channel_effectiveness', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('44', 'member', '用户名', 'can see member adhesive username column', 'member_adhesive', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('45', 'regdate', '注册时间', 'can see member adhesive regdate column', 'member_adhesive', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('46', 'first_deposit', '首存时间', 'can see member adhesive first_deposit column', 'member_adhesive', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('47', 'first_deposit_amount', '首存金额', 'can see member adhesive first_deposit_money column', 'member_adhesive', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('48', 'deposit_times', '存款次数', 'can see member adhesive deposit_times column', 'member_adhesive', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('49', 'deposit_amount', '累计存款', 'can see member adhesive deposit_sum_money column', 'member_adhesive', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('50', 'withdrawal_amount', '取款总额', 'can see member adhesive withdrawals_sum_money column', 'member_adhesive', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('51', 'bet_valid_amount', '投注码量', 'can see member adhesive realamount_sum_money column', 'member_adhesive', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('52', 'result_amount', '累计输赢', 'can see member adhesive uresult_sum column', 'member_adhesive', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('53', 'active_days', '活跃天数', 'can see member adhesive active_days column', 'member_adhesive', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('54', 'regip', 'IP地址', 'can see member adhesive regip column', 'member_adhesive', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('55', 'reg_device', '注册设备', 'can see member adhesive reg_device column', 'member_adhesive', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('56', 'reg_area', '开户省份', 'can see member adhesive reg_area column', 'member_adhesive', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('57', 'deposit_way', '存款方式', 'can see member adhesive deposit_way column', 'member_adhesive', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('58', 'deposit_devices', '存款设备', 'can see member adhesive deposit_devices column', 'member_adhesive', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('59', 'game_type', '游戏种类', 'can see member adhesive game_type column', 'member_adhesive', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('60', 'account_related', '是否关联账号', 'can see member adhesive account_related column', 'member_adhesive', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('61', 'bonus_normal', '一般贈金', 'can see member adhesive bonus column', 'member_adhesive', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('62', 'bonus_topic', '活動贈金', 'can see member adhesive integral column', 'member_adhesive', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('63', 'rake_back', '返水', 'can see member adhesive return_water column', 'member_adhesive', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('64', 'regdomain', '注册域名', 'can see member adhesive regdomain column', 'member_adhesive', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('65', 'add_channel_domain', '新增推廣域名', 'add channel domain', 'channel-management', 'ACTION', null, null);
INSERT INTO `permissions` VALUES ('66', 'edit_channel_domain', '修改推廣域名', 'edit channel domain', 'channel-management', 'ACTION', null, null);
INSERT INTO `permissions` VALUES ('67', 'delete_channel_domain', '刪除推廣域名', 'delete channel domain', 'channel-management', 'ACTION', null, null);
INSERT INTO `permissions` VALUES ('68', 'page-central-record', '後台操作記錄', 'enter central record', 'central-management', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('69', 'page-member-adhesive-first-deposit', '用戶首存留存表', 'enter member adhesive first deposit', 'member-management', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('70', 'page-member-adhesive-register', '用戶註冊留存表', 'enter member adhesive register', 'member-management', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('71', 'channel_delegation', '代理', 'can see member adhesive channel_delegation column', 'channel-group', 'REPORT_SCOPE', null, null);
INSERT INTO `permissions` VALUES ('72', 'channel_all', '推廣渠道', '推廣渠道', 'channel-group', 'REPORT_SCOPE', null, null);
INSERT INTO `permissions` VALUES ('73', 'channel_straight', '直客', '直客', 'channel-group', 'REPORT_SCOPE', null, null);
INSERT INTO `permissions` VALUES ('74', 'amount_real', '實際金額', '實際金額', 'report_field_type', 'REPORT_SCOPE', null, null);
INSERT INTO `permissions` VALUES ('75', 'manage_domain_with_all_owner', '管理推廣域名(可選全部行銷)', 'manage domain with all owner', 'channel-management', 'ACTION', null, null);
INSERT INTO `permissions` VALUES ('76', 'search_member_adhesive_with_target_time', '用戶留存表（搜尋目標時間）', '用戶留存表可以使用目標搜尋選項', 'member-management', 'ACTION', null, null);
INSERT INTO `permissions` VALUES ('77', 'sidebar-bankcard-management-group', '銀行卡管理選單', 'can see bankcard management sidebar group', 'bankcard-management', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('78', 'page-bankcard-group-summary', '組別結算', 'enter bankcard group summary', 'bankcard-management', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('79', 'page-member-detail', '查詢用戶信息', 'enter member detail', 'member-management', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('80', 'page-member-summary-related', '用戶關聯總攬', 'enter member summary related', 'member-management', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('81', 'online_deposited_person', '总活跃人数(有存款)', 'can see channel effectiveness deposit_user_count column', 'channel_effectiveness', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('82', 'online_deposited_person_sum', '总活跃天数(有存款)', 'can see channel effectiveness deposit_report_count column', 'channel_effectiveness', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('83', 'deposit_average_days', '平均活跃天数(有存款)', 'can see channel effectiveness deposit_average_days column', 'channel_effectiveness', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('84', 'sidebar-report-zone-group', '報表專區選單', 'can see report zone sidebar group', 'report-zone', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('85', 'page-report-zone-customer-service', '客服報表', 'enter report zone for customer service', 'report-zone', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('86', 'page-brand-overview', '品牌營運總覽', 'can see brand overview on dashboard', 'dashboard', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('87', 'page-member-manage-login-block', '登入凍結管理', 'enter member manage login block', 'member-management', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('88', 'sidebar-activity-management-group', '活動管理選單', 'can see activity management sidebar group', 'activity-management', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('89', 'page-activity-FlowChampion2017', '流水王爭霸賽', 'enter FlowChampion2017 management', 'activity-management', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('90', 'page-activity-FlowChampion2017-bet-history', '流水王爭霸賽投注記錄', 'enter FlowChampion2017 management bet history', 'activity-management', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('91', 'page-white-list', '白名單', '前端設定 註冊白名單 或 瀏覽頁面', 'fronted-setting', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('92', 'page-banner', '幻燈片', '前端設定 幻燈片', 'fronted-setting', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('93', 'page-game-slot', '電子遊戲', '前端設定 電子遊戲', 'game-manage', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('94', 'page-frontend-events', '活動設定', '前端設定 活動設定', 'fronted-setting', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('95', 'page-frontend-themes', '樣板子站設定', '前端設定 樣板子站設定', 'fronted-setting', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('96', 'page-report-zone-settlement-percentage', '結算比例 ', 'enter report zone for settlement percentage', 'report-zone', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('97', 'page-report-zone-bet-result-percentage', '平台殺數報表', '平台殺數報表', 'report-zone', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('98', 'sidebar-game-manage-group', '遊戲設定選單', '遊戲設定選單', 'game-manage', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('99', 'page-game-platform-manage', '平台設定', '平台設定', 'game-manage', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('100', 'page-member-summary-active-behavior', '用戶活躍行為', '用戶活躍行為', 'member-management', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('101', 'reg_mobile_person', '手機註冊', '查看手機註冊人數', 'channel_effectiveness', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('102', 'reg_app_person', 'app註冊', '查看app註冊人數', 'channel_effectiveness', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('103', 'deposit_admin_amount', '管理上分', '查看管理上分', 'channel_effectiveness', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('104', 'withdrawal_admin_amount', '管理下分', '查看管理下分', 'channel_effectiveness', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('105', 'pure_result', '純殺率', 'can see channel effectiveness pure_result column', 'channel_effectiveness', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('106', 'bet_divide_deposit', '投存比例', 'can see channel effectiveness bet_divide_deposit column', 'channel_effectiveness', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('107', 'pr_bonus_and_bet', '优惠投注比例', 'can see channel effectiveness pr_bonus_and_bet column', 'channel_effectiveness', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('108', 'pr_bonus_rake_back_and_deposit', '优惠存款比例', 'can see channel effectiveness pr_bonus_rake_back_and_deposit column', 'channel_effectiveness', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('109', 'sidebar-bet-history-group', '注單系統', '針對注單系統做的管理介面', 'bet-history', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('110', 'page-bet-summary', '下注總攬', '注單下注總攬', 'bet-history', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('111', 'page-bet-detail', '下注明細', '注單下注明細', 'bet-history', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('112', 'page-bet-settle', '結算紀錄', '注單結算紀錄', 'bet-history', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('113', 'page-bet-history', '下注紀錄', '會員下注紀錄', 'bet-history', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('114', 'pr_bet_result_amount', '杀数比', '杀数比', 'channel_effectiveness', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('115', 'bonus_agent', '代理贈金', '代理贈金', 'channel_effectiveness', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('116', 'bonus_agent', '代理贈金', '代理贈金', 'member_adhesive', 'REPORT_COLUMN', null, null);
INSERT INTO `permissions` VALUES ('117', 'page-bet-schedule', '排程', '注單排程管理', 'bet-history', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('118', 'channel_all', '排程', '注單排程管理', 'bet-history', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('119', 'page-member-signup-member', '創建新用戶', '創建新用戶', 'member-management', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('120', 'sidebar-system-record-group', '系統紀錄選單', '系統紀錄選單', 'system-task', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('121', 'page-system-task-history', '排程紀錄', '排程紀錄', 'system-task', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('122', 'sidebar-finance-group', '財務系統', '財務系統', 'finance', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('123', 'page-finance-bankcard', '銀行卡管理', '銀行卡管理', 'finance', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('124', 'page-telephone', '電銷系統', '電銷系統', 'telephone-group', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('125', 'page-telephone-member', '會員查詢', '電銷系統-會員查詢', 'telephone-group', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('126', 'page-telephone-record', '錄音查詢', '電銷系統-錄音查詢', 'telephone-group', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('127', 'page-telephone-statistics', '統計查詢', '電銷系統-統計查詢', 'telephone-group', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('128', 'page-telephone-library', '知識庫', '電銷系統-知識庫', 'telephone-group', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('129', 'page-telephone-task', '任務列表', '電銷系統-任務列表', 'telephone-group', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('130', 'page-telephone-upload', '上傳記錄', '電銷系統-上傳記錄', 'telephone-group', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('131', 'page-telephone-list', '電話列表', '電銷系統-電話列表', 'telephone-group', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('132', 'page-telephone-inspection', '稽核查詢', '電銷系統-稽核查詢', 'telephone-group', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('133', 'act-telephone-show-member', '電話列表  (是否顯示正式會員)', '電話列表是否顯示正式會員', 'telephone-group', 'ACTION', null, null);
INSERT INTO `permissions` VALUES ('134', 'act-telephone-is-uploadexcel', '是否能上傳電話', '是否能上傳電話', 'telephone-group', 'ACTION', null, null);
INSERT INTO `permissions` VALUES ('135', 'act-telephone-is-transfer', '電話轉移', '電話轉移', 'telephone-group', 'ACTION', null, null);
INSERT INTO `permissions` VALUES ('136', 'act-telephone-is-recycle', '電話回收', '電話回收', 'telephone-group', 'ACTION', null, null);
INSERT INTO `permissions` VALUES ('137', 'act-telephone-is-check-edit', '填寫稽查內容', '填寫稽查內容', 'telephone-group', 'ACTION', null, null);
INSERT INTO `permissions` VALUES ('138', 'act-telephone-is-conf-edit', '編輯配置內容', '編輯配置內容', 'telephone-group', 'ACTION', null, null);
INSERT INTO `permissions` VALUES ('139', 'act-telephone-dispatch-member', '會員任務', '會員任務', 'telephone-group', 'ACTION', null, null);
INSERT INTO `permissions` VALUES ('140', 'page-sms', '短信系統', '短信系統', 'sms-group', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('141', 'page-sms-account', '短信系統-帳號列表', '短信系統-帳號列表', 'sms-group', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('142', 'page-sms-record', '短信系統-紀錄列表', '短信系統-紀錄列表', 'sms-group', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('143', 'page-sms-template', '短信系統-樣板列表', '短信系統-樣板列表', 'sms-group', 'PAGE', null, null);
INSERT INTO `permissions` VALUES ('144', 'page-sms-statistic', '短信系統-統計查詢', '短信系統-統計查詢', 'sms-group', 'PAGE', null, null);

-- ----------------------------
-- Table structure for `permission_role`
-- ----------------------------
DROP TABLE IF EXISTS `permission_role`;
CREATE TABLE `permission_role` (
  `permission_id` int(10) unsigned NOT NULL COMMENT 'permission 表的 id',
  `role_id` int(10) unsigned NOT NULL COMMENT 'role 表的 id',
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `permission_role_role_id_foreign` (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of permission_role
-- ----------------------------
INSERT INTO `permission_role` VALUES ('1', '1');
INSERT INTO `permission_role` VALUES ('2', '1');
INSERT INTO `permission_role` VALUES ('3', '1');
INSERT INTO `permission_role` VALUES ('4', '1');
INSERT INTO `permission_role` VALUES ('5', '1');
INSERT INTO `permission_role` VALUES ('6', '1');
INSERT INTO `permission_role` VALUES ('7', '1');
INSERT INTO `permission_role` VALUES ('8', '1');
INSERT INTO `permission_role` VALUES ('9', '1');
INSERT INTO `permission_role` VALUES ('10', '1');
INSERT INTO `permission_role` VALUES ('11', '1');
INSERT INTO `permission_role` VALUES ('12', '1');
INSERT INTO `permission_role` VALUES ('13', '1');
INSERT INTO `permission_role` VALUES ('14', '1');
INSERT INTO `permission_role` VALUES ('15', '1');
INSERT INTO `permission_role` VALUES ('16', '1');
INSERT INTO `permission_role` VALUES ('17', '1');
INSERT INTO `permission_role` VALUES ('18', '1');
INSERT INTO `permission_role` VALUES ('19', '1');
INSERT INTO `permission_role` VALUES ('20', '1');
INSERT INTO `permission_role` VALUES ('21', '1');
INSERT INTO `permission_role` VALUES ('22', '1');
INSERT INTO `permission_role` VALUES ('23', '1');
INSERT INTO `permission_role` VALUES ('24', '1');
INSERT INTO `permission_role` VALUES ('25', '1');
INSERT INTO `permission_role` VALUES ('26', '1');
INSERT INTO `permission_role` VALUES ('27', '1');
INSERT INTO `permission_role` VALUES ('28', '1');
INSERT INTO `permission_role` VALUES ('29', '1');
INSERT INTO `permission_role` VALUES ('30', '1');
INSERT INTO `permission_role` VALUES ('31', '1');
INSERT INTO `permission_role` VALUES ('32', '1');
INSERT INTO `permission_role` VALUES ('33', '1');
INSERT INTO `permission_role` VALUES ('34', '1');
INSERT INTO `permission_role` VALUES ('35', '1');
INSERT INTO `permission_role` VALUES ('36', '1');
INSERT INTO `permission_role` VALUES ('37', '1');
INSERT INTO `permission_role` VALUES ('38', '1');
INSERT INTO `permission_role` VALUES ('39', '1');
INSERT INTO `permission_role` VALUES ('40', '1');
INSERT INTO `permission_role` VALUES ('41', '1');
INSERT INTO `permission_role` VALUES ('42', '1');
INSERT INTO `permission_role` VALUES ('43', '1');
INSERT INTO `permission_role` VALUES ('44', '1');
INSERT INTO `permission_role` VALUES ('45', '1');
INSERT INTO `permission_role` VALUES ('46', '1');
INSERT INTO `permission_role` VALUES ('47', '1');
INSERT INTO `permission_role` VALUES ('48', '1');
INSERT INTO `permission_role` VALUES ('49', '1');
INSERT INTO `permission_role` VALUES ('50', '1');
INSERT INTO `permission_role` VALUES ('51', '1');
INSERT INTO `permission_role` VALUES ('52', '1');
INSERT INTO `permission_role` VALUES ('53', '1');
INSERT INTO `permission_role` VALUES ('54', '1');
INSERT INTO `permission_role` VALUES ('55', '1');
INSERT INTO `permission_role` VALUES ('56', '1');
INSERT INTO `permission_role` VALUES ('57', '1');
INSERT INTO `permission_role` VALUES ('58', '1');
INSERT INTO `permission_role` VALUES ('59', '1');
INSERT INTO `permission_role` VALUES ('60', '1');
INSERT INTO `permission_role` VALUES ('61', '1');
INSERT INTO `permission_role` VALUES ('62', '1');
INSERT INTO `permission_role` VALUES ('63', '1');
INSERT INTO `permission_role` VALUES ('64', '1');
INSERT INTO `permission_role` VALUES ('65', '1');
INSERT INTO `permission_role` VALUES ('66', '1');
INSERT INTO `permission_role` VALUES ('67', '1');
INSERT INTO `permission_role` VALUES ('68', '1');
INSERT INTO `permission_role` VALUES ('69', '1');
INSERT INTO `permission_role` VALUES ('70', '1');
INSERT INTO `permission_role` VALUES ('71', '1');
INSERT INTO `permission_role` VALUES ('72', '1');
INSERT INTO `permission_role` VALUES ('73', '1');
INSERT INTO `permission_role` VALUES ('74', '1');
INSERT INTO `permission_role` VALUES ('75', '1');
INSERT INTO `permission_role` VALUES ('76', '1');
INSERT INTO `permission_role` VALUES ('77', '1');
INSERT INTO `permission_role` VALUES ('78', '1');
INSERT INTO `permission_role` VALUES ('79', '1');
INSERT INTO `permission_role` VALUES ('80', '1');
INSERT INTO `permission_role` VALUES ('81', '1');
INSERT INTO `permission_role` VALUES ('82', '1');
INSERT INTO `permission_role` VALUES ('83', '1');
INSERT INTO `permission_role` VALUES ('84', '1');
INSERT INTO `permission_role` VALUES ('85', '1');
INSERT INTO `permission_role` VALUES ('86', '1');
INSERT INTO `permission_role` VALUES ('87', '1');
INSERT INTO `permission_role` VALUES ('88', '1');
INSERT INTO `permission_role` VALUES ('89', '1');
INSERT INTO `permission_role` VALUES ('90', '1');
INSERT INTO `permission_role` VALUES ('91', '1');
INSERT INTO `permission_role` VALUES ('92', '1');
INSERT INTO `permission_role` VALUES ('93', '1');
INSERT INTO `permission_role` VALUES ('94', '1');
INSERT INTO `permission_role` VALUES ('95', '1');
INSERT INTO `permission_role` VALUES ('96', '1');
INSERT INTO `permission_role` VALUES ('97', '1');
INSERT INTO `permission_role` VALUES ('98', '1');
INSERT INTO `permission_role` VALUES ('99', '1');
INSERT INTO `permission_role` VALUES ('100', '1');
INSERT INTO `permission_role` VALUES ('101', '1');
INSERT INTO `permission_role` VALUES ('102', '1');
INSERT INTO `permission_role` VALUES ('103', '1');
INSERT INTO `permission_role` VALUES ('104', '1');
INSERT INTO `permission_role` VALUES ('105', '1');
INSERT INTO `permission_role` VALUES ('106', '1');
INSERT INTO `permission_role` VALUES ('107', '1');
INSERT INTO `permission_role` VALUES ('108', '1');
INSERT INTO `permission_role` VALUES ('109', '1');
INSERT INTO `permission_role` VALUES ('110', '1');
INSERT INTO `permission_role` VALUES ('111', '1');
INSERT INTO `permission_role` VALUES ('112', '1');
INSERT INTO `permission_role` VALUES ('113', '1');
INSERT INTO `permission_role` VALUES ('114', '1');
INSERT INTO `permission_role` VALUES ('115', '1');
INSERT INTO `permission_role` VALUES ('116', '1');
INSERT INTO `permission_role` VALUES ('117', '1');
INSERT INTO `permission_role` VALUES ('118', '1');
INSERT INTO `permission_role` VALUES ('119', '1');
INSERT INTO `permission_role` VALUES ('120', '1');
INSERT INTO `permission_role` VALUES ('121', '1');
INSERT INTO `permission_role` VALUES ('122', '1');
INSERT INTO `permission_role` VALUES ('123', '1');
INSERT INTO `permission_role` VALUES ('124', '1');
INSERT INTO `permission_role` VALUES ('125', '1');
INSERT INTO `permission_role` VALUES ('126', '1');
INSERT INTO `permission_role` VALUES ('127', '1');
INSERT INTO `permission_role` VALUES ('128', '1');
INSERT INTO `permission_role` VALUES ('129', '1');
INSERT INTO `permission_role` VALUES ('130', '1');
INSERT INTO `permission_role` VALUES ('131', '1');
INSERT INTO `permission_role` VALUES ('132', '1');
INSERT INTO `permission_role` VALUES ('133', '1');
INSERT INTO `permission_role` VALUES ('134', '1');
INSERT INTO `permission_role` VALUES ('135', '1');
INSERT INTO `permission_role` VALUES ('136', '1');
INSERT INTO `permission_role` VALUES ('137', '1');
INSERT INTO `permission_role` VALUES ('138', '1');
INSERT INTO `permission_role` VALUES ('139', '1');
INSERT INTO `permission_role` VALUES ('140', '1');
INSERT INTO `permission_role` VALUES ('141', '1');
INSERT INTO `permission_role` VALUES ('142', '1');
INSERT INTO `permission_role` VALUES ('143', '1');
INSERT INTO `permission_role` VALUES ('144', '1');

-- ----------------------------
-- Table structure for `provider_telephone_support`
-- ----------------------------
DROP TABLE IF EXISTS `provider_telephone_support`;
CREATE TABLE `provider_telephone_support` (
  `telephone_prefix` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '手机号前7位',
  `district` int(10) unsigned DEFAULT NULL COMMENT '区号',
  `province` varchar(12) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '省',
  `city` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '市',
  `operator` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '运营商',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`telephone_prefix`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of provider_telephone_support
-- ----------------------------

-- ----------------------------
-- Table structure for `reg_ip`
-- ----------------------------
DROP TABLE IF EXISTS `reg_ip`;
CREATE TABLE `reg_ip` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `member_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('SUCCESS','BLOCK') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'SUCCESS',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of reg_ip
-- ----------------------------

-- ----------------------------
-- Table structure for `roles`
-- ----------------------------
DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '職位英文名稱',
  `display_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '職位中文顯示名稱',
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '職位描敘',
  `left` smallint(6) DEFAULT NULL COMMENT '計算職位上下從屬的左節點',
  `right` smallint(6) DEFAULT NULL COMMENT '計算職位上下從屬的右節點',
  `depth` tinyint(4) DEFAULT NULL COMMENT '計算職位上下從屬的深度',
  `level` enum('1','2','3','4','5') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '5' COMMENT '組織層級',
  `group` enum('marketing','server','developer','money','super','customer_service','operation','other','accountant') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'other' COMMENT '職位類別',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of roles
-- ----------------------------
INSERT INTO `roles` VALUES ('1', 'super', '超級管理者', null, '1', '32', null, '1', 'super', '2019-01-11 16:41:58', '2019-01-11 16:41:58');

-- ----------------------------
-- Table structure for `role_user`
-- ----------------------------
DROP TABLE IF EXISTS `role_user`;
CREATE TABLE `role_user` (
  `user_id` int(10) unsigned NOT NULL COMMENT 'administrator 表的 id',
  `role_id` int(10) unsigned NOT NULL COMMENT 'role 表的 id',
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `role_user_role_id_foreign` (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of role_user
-- ----------------------------
INSERT INTO `role_user` VALUES ('1', '1');

-- ----------------------------
-- Table structure for `setting`
-- ----------------------------
DROP TABLE IF EXISTS `setting`;
CREATE TABLE `setting` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `value` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of setting
-- ----------------------------
INSERT INTO `setting` VALUES ('1', '客服連結PC', 'customer_service_pc', '', null, null);
INSERT INTO `setting` VALUES ('2', '客服連結Moblie', 'customer_service_m', '', null, null);
INSERT INTO `setting` VALUES ('3', 'App下載連結(Android)', 'app_android', '', null, null);
INSERT INTO `setting` VALUES ('4', 'App下載連結(IOS)', 'app_ios', '', null, null);
INSERT INTO `setting` VALUES ('5', 'App版號(Android)', 'app_android_version_code', '', null, null);
INSERT INTO `setting` VALUES ('6', 'App版號(IOS)', 'app_ios_version_code', '', null, null);
INSERT INTO `setting` VALUES ('7', 'App顯示版本(Android)', 'app_android_version', '', null, null);
INSERT INTO `setting` VALUES ('8', 'App顯示版本(IOS)', 'app_ios_version', '', null, null);
INSERT INTO `setting` VALUES ('9', '緊急訊息', 'emergency_msg', '', null, null);
INSERT INTO `setting` VALUES ('10', '監控代碼', 'monitor', '', null, null);
INSERT INTO `setting` VALUES ('11', 'cdn連結(Javascript)', 'cdn_js', '', null, null);
INSERT INTO `setting` VALUES ('12', 'cdn連結(Image)', 'cdn_image', '', null, null);
INSERT INTO `setting` VALUES ('13', '會員中心連結(PC)', 'member_center_pc', '', null, null);
INSERT INTO `setting` VALUES ('14', '會員中心連結(Mobile)', 'member_center_m', '', null, null);
INSERT INTO `setting` VALUES ('15', '註冊限制時間', 'block_time', '', null, null);
INSERT INTO `setting` VALUES ('16', '會員中心API', 'member_center_api', '', null, null);

-- ----------------------------
-- Table structure for `sms_account`
-- ----------------------------
DROP TABLE IF EXISTS `sms_account`;
CREATE TABLE `sms_account` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '廠商的 apikey',
  `secret_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '某些廠商可能會有 secret_key',
  `account` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '帳號名稱',
  `provider` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '廠商名稱',
  `remark` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '備註',
  `status` tinyint(3) unsigned NOT NULL DEFAULT 1 COMMENT '狀態 0 禁用,1 啟動',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of sms_account
-- ----------------------------
INSERT INTO `sms_account` VALUES ('1', '826dce645b70b511f2075be209fbf07a', 'fab84c1313905e8a8d826598fa721964', 'xpowlowski@ondricka.biz', 'Nexmo', '碗回村。他想了一層。', '1', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_account` VALUES ('2', '28e0be4868ab404783afa8198e4a6f2e', 'a93a968349aaf66011a44312ad07b0f9', 'baylee21@yahoo.com', 'Yunpian', '其是在他們不記得。', '1', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_account` VALUES ('3', 'a99be407dee384b256b611241a7f543e', 'd0dc5754af6c098c3b6c32cebbd49e10', 'joanie.franecki@hotmail.com', 'Yunpian', '竹杠又向外一望烏黑。', '1', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_account` VALUES ('4', '2272f3cf80b1b9a595281cde661edec0', '433aa1f10bd8429a0dbdc18f61965370', 'dickinson.carlo@casper.com', 'Nexmo', '人的墳墓也早經說過。', '0', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_account` VALUES ('5', '51660cac9a1af0fbbf473e27badad254', 'a70f4e0e8469bf5389018f9e2320530e', 'sierra.mraz@stiedemann.com', 'Yunpian', '稱郡望的老婆跳了三。', '0', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_account` VALUES ('6', 'd1449d1cc185f256ca5a5ca229b4dd36', '7567e47425b8f340bdab9ef632ad6279', 'ikris@kiehn.biz', 'Yunpian', '的吹來；車夫麼？”。', '0', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_account` VALUES ('7', '6f6dcb60165825e8dedb8bb8fdddb9e5', '20b677c69377fba1ac71eed9ede9b8a0', 'schmitt.brigitte@hotmail.com', 'Yunpian', '想又仿佛微塵似的提。', '1', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_account` VALUES ('8', '76b9b20cb5729f24da37df4628c0e502', 'a21b7de45ad782c65ac7c1f87fbdc8c1', 'kilback.moises@homenick.com', 'Nexmo', '子又盤在頭頸上套一。', '1', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_account` VALUES ('9', 'ee8f3ab086eb572b11db04e407bc443c', '5802d8b62f47ee26da3d2598de5d1a5c', 'fiona.lakin@bruen.biz', 'Yunpian', '也讀過書的人們忙碌。', '1', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_account` VALUES ('10', 'db898ecf73bbd3b742dfc363ad0dd309', '22af30b07a313e63c934aec98e1428d2', 'freda.rippin@jones.com', 'Yunpian', '了一刻，額上滾下。', '0', '2019-01-11 16:42:00', '2019-01-11 16:42:00');

-- ----------------------------
-- Table structure for `sms_log`
-- ----------------------------
DROP TABLE IF EXISTS `sms_log`;
CREATE TABLE `sms_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `telephone_id` int(10) unsigned NOT NULL DEFAULT 0 COMMENT '電話 id',
  `fee` double(15,4) NOT NULL DEFAULT 0.0000 COMMENT '電話費用,精準到小數點4位',
  `admin_id` int(11) NOT NULL COMMENT '發送者',
  `account_id` int(11) NOT NULL COMMENT '發送帳號 id',
  `content` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '發送內容',
  `phone` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '電話號碼加密',
  `currency` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '貨幣',
  `department` tinyint(3) unsigned NOT NULL DEFAULT 1 COMMENT '0 系統,1 電銷',
  `status` tinyint(3) unsigned NOT NULL DEFAULT 1 COMMENT '發送狀態 0 失敗,1 成功',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=301 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of sms_log
-- ----------------------------
INSERT INTO `sms_log` VALUES ('1', '1', '0.0000', '5', '1', '很有些古風：不過改。', '+6945181779942', 'USD', '1', '1', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('2', '2', '0.0000', '39', '1', '打，從十一點來煮吃。', '+8613973856730', 'USD', '0', '0', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('3', '3', '0.0000', '73', '1', '此，可以釣到一個畫。', '+1595567632109', 'USD', '1', '0', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('4', '4', '0.0056', '72', '1', '也就從嗚咽變成明天。', '+4246614503407', 'RMB', '1', '1', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('5', '5', '0.0000', '4', '1', '歡他們來玩耍；他求。', '+1437114277017', 'RMB', '1', '1', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('6', '6', '0.0061', '22', '1', '訴我，也只得將靈魂。', '+3606332782000', 'USD', '1', '1', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('7', '7', '0.0000', '1', '1', '城裏做編輯的大皮夾。', '+8404388184640', 'USD', '0', '0', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('8', '8', '0.0000', '6', '1', '活的人也很老的氣。', '+5701598579562', 'RMB', '0', '1', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('9', '9', '0.0000', '67', '1', '小栓一手捏一柄鋼叉。', '+3351519861667', 'USD', '0', '0', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('10', '10', '0.0050', '98', '1', '請」，一字兒排着。', '+2434950774081', 'RMB', '0', '1', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('11', '11', '0.0026', '18', '1', '子，多是水田，打了。', '+8535430929982', 'RMB', '0', '0', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('12', '12', '0.0045', '92', '1', '茶館裏有三無後為大。', '+9116084824599', 'USD', '0', '0', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('13', '13', '0.0000', '15', '1', '很模胡了。他很想尋。', '+8953352649334', 'RMB', '1', '0', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('14', '14', '0.0075', '26', '1', '得哩。我雖然我一眼。', '+8826031912386', 'RMB', '0', '0', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('15', '15', '0.0077', '95', '1', '過了，也仍然簌簌的。', '+7389821211507', 'RMB', '1', '0', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('16', '16', '0.0030', '44', '1', '服前後的跳，一齊走。', '+2355463995303', 'USD', '1', '1', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('17', '17', '0.0000', '64', '1', '去消夏。那時不也說。', '+3171972569285', 'USD', '1', '1', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('18', '18', '0.0076', '24', '1', ' 「老栓便把一個畫。', '+7378087690292', 'RMB', '0', '1', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('19', '19', '0.0000', '65', '1', '法，來折服了，戲文。', '+8678087510314', 'RMB', '1', '0', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('20', '20', '0.0000', '11', '1', '出廚房裡，出入于國。', '+9941469994424', 'USD', '0', '0', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('21', '21', '0.0000', '27', '1', '邊。——在……留幾。', '+5640681520452', 'RMB', '0', '0', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('22', '22', '0.0100', '98', '1', ' 這村莊；平橋了。', '+9510013531237', 'RMB', '0', '0', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('23', '23', '0.0036', '50', '1', '的：都是碧綠的在腦。', '+9326100137028', 'USD', '0', '1', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('24', '24', '0.0075', '92', '1', '一定說是大半沒有系。', '+3124010791532', 'RMB', '0', '0', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('25', '25', '0.0033', '13', '1', '橋村五里的萬流湖裏。', '+7674269464368', 'USD', '0', '0', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('26', '26', '0.0045', '12', '1', '落，一早在路上走著。', '+2556645337623', 'USD', '0', '1', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('27', '27', '0.0087', '78', '1', '七爺說到希望，只能。', '+8830380270314', 'RMB', '1', '0', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('28', '28', '0.0053', '72', '1', '門口豎著許多皺紋。', '+2522163132608', 'USD', '0', '1', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('29', '29', '0.0080', '78', '1', '外十之九十九個錢呢。', '+9203886541142', 'USD', '1', '0', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('30', '30', '0.0000', '60', '1', '胡叉呢。 但阿五。', '+9641727018443', 'USD', '0', '1', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('31', '31', '0.0080', '86', '2', '記着！這樣遲，是女。', '+5079010894566', 'USD', '1', '0', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('32', '32', '0.0000', '36', '2', '的院子去，漸漸的有。', '+2948761713258', 'USD', '1', '1', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('33', '33', '0.0060', '26', '2', '臉油汗，瞪着眼眶。', '+8744872371447', 'USD', '0', '0', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('34', '34', '0.0055', '92', '2', '家做短工的人也一樣。', '+5329582966427', 'RMB', '0', '1', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('35', '35', '0.0040', '53', '2', '自然是可以偷一點薪。', '+6929840623567', 'RMB', '0', '1', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('36', '36', '0.0100', '73', '2', '小鬼見閻王臉，竭力。', '+3842598950272', 'RMB', '1', '1', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('37', '37', '0.0077', '42', '2', '的白背心。於是遞給。', '+7069800031996', 'USD', '0', '0', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('38', '38', '0.0000', '95', '2', '此。於是發生了敵愾。', '+8878801485674', 'RMB', '0', '0', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('39', '39', '0.0083', '87', '2', '微風吹進船艙中，在。', '+7400496354864', 'USD', '1', '1', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('40', '40', '0.0000', '24', '2', '響，頗震得手腕痛。', '+1344591606766', 'USD', '0', '1', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('41', '41', '0.0094', '27', '2', '麽？ “我”去叫小。', '+9443769254704', 'USD', '1', '1', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('42', '42', '0.0000', '82', '2', '聲看時，他也漸漸的。', '+7025615019452', 'RMB', '1', '1', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('43', '43', '0.0055', '70', '2', '顯出人物來，驚起了。', '+4053118454182', 'RMB', '1', '0', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('44', '44', '0.0000', '20', '2', '問他買綢裙，要侮蔑。', '+2643442342311', 'RMB', '1', '1', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('45', '45', '0.0088', '4', '2', '蔑的抬起眼來說，。', '+3087389299830', 'USD', '1', '1', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('46', '46', '0.0060', '57', '2', '的卻來領我們上船的。', '+1555297764335', 'RMB', '0', '0', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('47', '47', '0.0018', '68', '2', '未達到身上，這墳裏。', '+6278299868614', 'RMB', '1', '1', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('48', '48', '0.0074', '43', '2', '方玄綽低下頭顱來示。', '+2176262205073', 'RMB', '1', '1', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('49', '49', '0.0012', '100', '2', '無可吿語，而且並不。', '+8280972746642', 'RMB', '0', '0', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('50', '50', '0.0040', '46', '2', '扁額，……”阿Q。', '+9874751242014', 'USD', '0', '0', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('51', '51', '0.0000', '68', '2', '空氣。他留心打聽。', '+5147626116558', 'RMB', '0', '1', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('52', '52', '0.0038', '56', '2', '他卻又提起閏土這名。', '+8712347870711', 'USD', '0', '1', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('53', '53', '0.0000', '3', '2', '沒有號——大蹋步走。', '+1634478058080', 'USD', '0', '0', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('54', '54', '0.0059', '33', '2', '來或者因為文體卑下。', '+3961526727140', 'USD', '1', '0', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('55', '55', '0.0031', '11', '2', '而又擠，覺得人說。', '+2156010207761', 'USD', '0', '0', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('56', '56', '0.0099', '64', '2', '的躄進去，船便撐船。', '+8968156788197', 'RMB', '1', '0', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('57', '57', '0.0000', '36', '2', '我又不准革命黨的口。', '+7366357500517', 'USD', '0', '1', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('58', '58', '0.0049', '18', '2', '是我們魯鎮的戲可好。', '+2892182530761', 'RMB', '0', '0', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('59', '59', '0.0100', '11', '2', '負，然而阿Q雖然記。', '+9979188818729', 'RMB', '1', '0', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('60', '60', '0.0071', '39', '2', ' 我懂得文章了，又。', '+1545672240049', 'RMB', '0', '1', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('61', '61', '0.0078', '35', '3', '去的唱，看見死的！', '+3676287457588', 'RMB', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('62', '62', '0.0039', '67', '3', '直的樹上，管土穀祠。', '+9892616283027', 'RMB', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('63', '63', '0.0082', '22', '3', '然，拍案打凳的說。', '+5901566290874', 'RMB', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('64', '64', '0.0020', '50', '3', '太濫了，他忽而聽的。', '+1729161808414', 'RMB', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('65', '65', '0.0011', '19', '3', '的門檻上，你放了心。', '+2334969262254', 'RMB', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('66', '66', '0.0100', '56', '3', '的本多博士的吁氣。', '+5586742937901', 'RMB', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('67', '67', '0.0004', '79', '3', '接近了，我們的生活。', '+5176613639643', 'RMB', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('68', '68', '0.0012', '19', '3', '我手執鋼鞭，於是往。', '+4956974264733', 'RMB', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('69', '69', '0.0000', '69', '3', '着熱鬧，我疑心老旦。', '+2101551488904', 'USD', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:00');
INSERT INTO `sms_log` VALUES ('70', '70', '0.0056', '29', '3', '而且欣然了。」 。', '+2701808068513', 'USD', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('71', '71', '0.0000', '1', '3', '係，不能不再被人罵。', '+8694241012305', 'USD', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('72', '72', '0.0000', '38', '3', '章，有的勃然了，在。', '+2148450452682', 'USD', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('73', '73', '0.0089', '8', '3', '經發了瘋了。我已經。', '+6263787692901', 'RMB', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('74', '74', '0.0044', '71', '3', '老栓也向那松柏林。', '+1558309903755', 'RMB', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('75', '75', '0.0000', '6', '3', '京的留學，回來的結。', '+3290674260475', 'RMB', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('76', '76', '0.0028', '60', '3', '自造的洞，再沒有同。', '+3284544644603', 'USD', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('77', '77', '0.0084', '27', '3', '燈光下，眼裏了，這。', '+2832549824160', 'USD', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('78', '78', '0.0000', '38', '3', '一塊大方磚來，咿咿。', '+7214485614914', 'USD', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('79', '79', '0.0014', '17', '3', '的天空中掛著一隻大。', '+5325621795164', 'USD', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('80', '80', '0.0035', '69', '3', '要的，裏面呢還是罵。', '+3383428609770', 'RMB', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('81', '81', '0.0000', '94', '3', '小白兔的蹤跡，倘自。', '+7185053676587', 'RMB', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('82', '82', '0.0090', '69', '3', '四，是一個泥人，好。', '+6630591731641', 'RMB', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('83', '83', '0.0056', '9', '3', '人家做工，並不看見。', '+6205465541649', 'USD', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('84', '84', '0.0000', '57', '3', '買稿要一個朋友去借。', '+1316896657933', 'USD', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('85', '85', '0.0068', '3', '3', '我說，「這是怎樣…。', '+9505884248407', 'RMB', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('86', '86', '0.0020', '7', '3', '窮了一點半，從來沒。', '+1416103751352', 'RMB', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('87', '87', '0.0000', '47', '3', '麻醉自己的寂寞了。', '+1879829025202', 'RMB', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('88', '88', '0.0078', '1', '3', '我要替小兔到洞門口。', '+8628192397986', 'USD', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('89', '89', '0.0030', '45', '3', '了兩塊！”秀才在後。', '+3079886223031', 'USD', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('90', '90', '0.0000', '39', '3', '購來的一聲脆響，最。', '+5084356746351', 'USD', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('91', '91', '0.0077', '72', '4', '有一個謎語的說。 。', '+7645111354634', 'RMB', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('92', '92', '0.0077', '58', '4', '年有了他的兒子茂才。', '+9020793707087', 'USD', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('93', '93', '0.0100', '29', '4', '麽？”“改革了命。', '+6077436982173', 'USD', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('94', '94', '0.0068', '93', '4', '剃得精光像這老爺想。', '+3490181632636', 'USD', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('95', '95', '0.0099', '13', '4', '嘗試集》。 所以也。', '+4210129016427', 'RMB', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('96', '96', '0.0000', '22', '4', '了機會，——」九斤。', '+3067600669493', 'USD', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('97', '97', '0.0078', '100', '4', '跟；王九媽便出了。', '+6555666434207', 'RMB', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('98', '98', '0.0038', '16', '4', '蚊子在這小孤孀不知。', '+6827926673467', 'USD', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('99', '99', '0.0040', '21', '4', '罷了。於是打，看去。', '+6181703404987', 'USD', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('100', '100', '0.0019', '7', '4', '篇速朽的文章。」 。', '+4211745277788', 'RMB', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('101', '101', '0.0050', '20', '4', '於他也不敢來放肆。', '+1409943033248', 'USD', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('102', '102', '0.0073', '13', '4', '步，尋聲走出下面哼。', '+7794555530940', 'RMB', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('103', '103', '0.0055', '52', '4', ' 第九章 不准我造。', '+4356315122810', 'USD', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('104', '104', '0.0100', '68', '4', '慢慢起來，趁這機會。', '+7794425004856', 'USD', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('105', '105', '0.0080', '38', '4', '了。 母親說著話。', '+9338389976824', 'RMB', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('106', '106', '0.0048', '92', '4', '間直熱到臉上蓋：因。', '+6191496655545', 'USD', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('107', '107', '0.0036', '75', '4', '罷？”伊大吃一點頭。', '+6747851570783', 'USD', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('108', '108', '0.0000', '57', '4', '法，現在太新奇，令。', '+4712048494964', 'RMB', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('109', '109', '0.0017', '39', '4', '一隻大手，用圈子將。', '+3652505660387', 'USD', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('110', '110', '0.0000', '45', '4', '抖著，也只能爛掉…。', '+7904803277252', 'USD', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('111', '111', '0.0010', '51', '4', '命黨還不聽到孩子喫。', '+3164192038965', 'USD', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('112', '112', '0.0000', '86', '4', '鋒利，不很有些古怪。', '+1222397817236', 'RMB', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('113', '113', '0.0000', '46', '4', 'S便退三步，這一篇。', '+4784471288622', 'RMB', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('114', '114', '0.0060', '92', '4', 'Q想。 華大媽也黑。', '+7924061311819', 'RMB', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('115', '115', '0.0097', '5', '4', '訥的他便罵，很近於。', '+5800860953436', 'USD', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('116', '116', '0.0000', '15', '4', '畫得很利害，聚精會。', '+3039012283212', 'RMB', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('117', '117', '0.0084', '91', '4', '皮裏面了。幾個人一。', '+6872244588973', 'USD', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('118', '118', '0.0000', '36', '4', '大的缺點，忽而耳朵。', '+4645539782713', 'RMB', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('119', '119', '0.0042', '17', '4', '在棒上的閏土又對我。', '+2968297701420', 'RMB', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('120', '120', '0.0000', '26', '4', '竟太寂靜。但在我心。', '+3594812332907', 'RMB', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('121', '121', '0.0000', '93', '5', '以至於處所，那一定。', '+4429556799772', 'RMB', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('122', '122', '0.0100', '82', '5', '有說，這次回鄉，搬。', '+9308591742546', 'RMB', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('123', '123', '0.0084', '1', '5', '的侄兒宏兒和他們！', '+6925559128528', 'USD', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('124', '124', '0.0086', '54', '5', '不至於被槍斃便是一。', '+7626987412287', 'USD', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('125', '125', '0.0024', '42', '5', '喝了一輛沒有人來。', '+8676553082790', 'USD', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('126', '126', '0.0000', '60', '5', '死囚呵，游了那時是。', '+7411209867807', 'USD', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('127', '127', '0.0100', '9', '5', '抓進抓出柵欄門去。', '+7966051042751', 'RMB', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('128', '128', '0.0032', '43', '5', '索索的荒村，看見王。', '+8314597364703', 'RMB', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('129', '129', '0.0068', '42', '5', '而他現在。仰起頭。', '+3093516412368', 'RMB', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('130', '130', '0.0000', '10', '5', '書了，這總該還在。', '+5308345405425', 'USD', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('131', '131', '0.0000', '93', '5', '太爺的兒子和別人的。', '+1061505149461', 'RMB', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('132', '132', '0.0030', '6', '5', '似乎連成一支手杖來。', '+4117410603628', 'RMB', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('133', '133', '0.0000', '12', '5', '在熱水裏，都向後退。', '+4675158641301', 'USD', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('134', '134', '0.0000', '60', '5', '該還有油菜早經說過。', '+8424268374425', 'RMB', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('135', '135', '0.0082', '34', '5', '約本來說。 “咳～。', '+8216078275313', 'USD', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('136', '136', '0.0048', '96', '5', '頭，說「請請」，渾。', '+7826959712498', 'USD', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('137', '137', '0.0080', '68', '5', '一面聽，然而這正如。', '+9081980889751', 'RMB', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('138', '138', '0.0000', '46', '5', '仰。我的麻醉自己的。', '+8418780583544', 'USD', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('139', '139', '0.0000', '57', '5', '了大門走去了。\" 。', '+4815166813546', 'RMB', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('140', '140', '0.0000', '57', '5', '最要緊的只有假洋鬼。', '+5861213671631', 'RMB', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('141', '141', '0.0000', '46', '5', '阿Q的名字是怎麼好。', '+2090526194007', 'USD', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('142', '142', '0.0011', '30', '5', '生論》講佛學的時候。', '+8499660617107', 'RMB', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('143', '143', '0.0072', '24', '5', '去了。 方玄綽近來。', '+4453641152503', 'USD', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('144', '144', '0.0043', '59', '5', '北風颳得正高興再幫。', '+8460349892819', 'RMB', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('145', '145', '0.0100', '16', '5', '有殃了。 「是的。', '+9642839627895', 'USD', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('146', '146', '0.0090', '37', '5', '面前。 阿Q放下了。', '+2645752725405', 'USD', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('147', '147', '0.0098', '28', '5', '起這黑東西了。 。', '+2164957517072', 'RMB', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('148', '148', '0.0100', '11', '5', '不住滿心痛恨起來。', '+5905305492256', 'RMB', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('149', '149', '0.0013', '33', '5', '叫天還沒有現在不見。', '+1329064109009', 'RMB', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('150', '150', '0.0039', '41', '5', '失望，那孩子們笑得。', '+8253767324915', 'RMB', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('151', '151', '0.0030', '66', '6', '阿Q吃虧的時候，忽。', '+2601265721127', 'RMB', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('152', '152', '0.0094', '44', '6', '” “你鈔他是和尚。', '+1593898710618', 'USD', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('153', '153', '0.0066', '41', '6', '目；我卻並沒有走就。', '+8292790909209', 'USD', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('154', '154', '0.0070', '1', '6', '笑。 我的確守了寡。', '+2741259648277', 'RMB', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('155', '155', '0.0030', '51', '6', '怕是可敬的垂着；笑。', '+8518910320129', 'RMB', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('156', '156', '0.0015', '80', '6', '友的，可惜腳太大。', '+3169064745613', 'RMB', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('157', '157', '0.0000', '70', '6', '興，問伊說：那時嚇。', '+1626366637797', 'USD', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('158', '158', '0.0004', '100', '6', '得驚異，說，皇帝已。', '+8678075350118', 'USD', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('159', '159', '0.0086', '44', '6', ' 掌柜，托他的太牢。', '+7947765021907', 'USD', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('160', '160', '0.0000', '36', '6', '走過面前道，「孔乙。', '+6281967716126', 'RMB', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('161', '161', '0.0000', '80', '6', '方太太正在七斤嫂。', '+2601945478244', 'RMB', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('162', '162', '0.0011', '87', '6', '六斤剛喫完豆，做下。', '+6856587340871', 'USD', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('163', '163', '0.0000', '90', '6', '人可惡，假使造物太。', '+3490262984349', 'RMB', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('164', '164', '0.0040', '29', '6', '麼？你娘會安排停當。', '+5552874781305', 'USD', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('165', '165', '0.0093', '37', '6', '這總該有一點乾青豆。', '+8997608516498', 'USD', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('166', '166', '0.0000', '64', '6', '的回到土穀祠，放倒。', '+5966400549430', 'USD', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('167', '167', '0.0000', '90', '6', '道不妙，但屋內是王。', '+1459996129661', 'RMB', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('168', '168', '0.0095', '29', '6', '書應試是正人，花白。', '+5327567880895', 'RMB', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('169', '169', '0.0038', '85', '6', '三回，他可會寫字。', '+8611380318863', 'RMB', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('170', '170', '0.0007', '15', '6', '忽聽得許多時，本是。', '+4708142278020', 'USD', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('171', '171', '0.0000', '52', '6', '去，他們胡亂的包藥。', '+3247540778499', 'RMB', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('172', '172', '0.0000', '26', '6', ' 阿！這模樣，所以。', '+1606280460134', 'USD', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('173', '173', '0.0000', '20', '6', '間已經關了門，便又。', '+7714927557987', 'RMB', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('174', '174', '0.0087', '54', '6', '愈窮，弄到將要討飯。', '+8877793286841', 'USD', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('175', '175', '0.0098', '39', '6', '縫裡看那王胡尚且那。', '+2601316305968', 'RMB', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('176', '176', '0.0100', '37', '6', '走著的一彈地，怎樣。', '+2396161969612', 'RMB', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('177', '177', '0.0032', '93', '6', '之鬼餒而”，本來可。', '+8510362309890', 'RMB', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('178', '178', '0.0080', '2', '6', '頭的老頭子催他走。', '+4288259190106', 'USD', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('179', '179', '0.0012', '78', '6', '的。你看，——第一。', '+6558610756523', 'RMB', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('180', '180', '0.0037', '14', '6', '的，一直散到老主顧。', '+7333252554490', 'USD', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('181', '181', '0.0077', '39', '7', '空地呢……。」「什。', '+9370128970760', 'USD', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('182', '182', '0.0100', '18', '7', '桕樹葉銜進洞裏去。', '+2999415883872', 'USD', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('183', '183', '0.0000', '54', '7', '掌櫃取下一片碗筷聲。', '+8969415967903', 'RMB', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('184', '184', '0.0100', '53', '7', '但不知道這是怎麼走。', '+7726116064026', 'USD', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('185', '185', '0.0038', '70', '7', '了。他得意，而且表。', '+9828912425554', 'USD', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('186', '186', '0.0000', '72', '7', '投意合的，但我們的。', '+5972759623922', 'USD', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('187', '187', '0.0000', '8', '7', '三爺真是貴人眼睛講。', '+4220276656851', 'RMB', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('188', '188', '0.0100', '87', '7', '斗，只有一個男人。', '+5098180167384', 'RMB', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('189', '189', '0.0095', '81', '7', '玩了。何小仙伸開五。', '+2311547443544', 'USD', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('190', '190', '0.0100', '83', '7', '了節麽？我活了七十。', '+1913374563290', 'USD', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('191', '191', '0.0090', '18', '7', '這一部書，換一碗酒。', '+2074271643967', 'RMB', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('192', '192', '0.0044', '30', '7', '頭，眼裏頗清靜了。', '+4975525395404', 'RMB', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('193', '193', '0.0005', '91', '7', '友，即使偶而吵鬧起。', '+6450864609022', 'USD', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('194', '194', '0.0000', '1', '7', '大的似乎是一個小銀。', '+4899894980144', 'RMB', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('195', '195', '0.0087', '65', '7', '趙莊。那時是二元的。', '+6617961243159', 'USD', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('196', '196', '0.0001', '47', '7', '可以寫包票！船又大。', '+5550362606753', 'USD', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('197', '197', '0.0033', '40', '7', '回頭去看。 酒店的。', '+8146035782355', 'USD', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('198', '198', '0.0000', '45', '7', '事的案卷裏並無與阿。', '+7608319569757', 'USD', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('199', '199', '0.0069', '38', '7', '了一嚇，不久豆熟了。', '+9960523793353', 'USD', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('200', '200', '0.0000', '83', '7', '便連喂他們都如我那。', '+7232317310619', 'USD', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('201', '201', '0.0040', '37', '7', '會來？\" 我懂得。', '+3699113826727', 'USD', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('202', '202', '0.0026', '34', '7', '”這一天的長毛，只。', '+9664783291653', 'USD', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('203', '203', '0.0033', '41', '7', '加了一下，商量了對。', '+2336190785317', 'RMB', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('204', '204', '0.0051', '100', '7', '之乎者也曾告訴過管。', '+7013332107655', 'USD', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('205', '205', '0.0069', '18', '7', '在他房裏轉過向來少。', '+9178877807370', 'USD', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('206', '206', '0.0000', '29', '7', '吃過晚飯桌上。他能。', '+1630832749586', 'RMB', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('207', '207', '0.0076', '18', '7', ' 但對面挺直的站著。', '+1547277020787', 'RMB', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('208', '208', '0.0100', '84', '7', '平……\" 我想，趁。', '+8148029490208', 'USD', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('209', '209', '0.0029', '96', '7', '但我們要革得我晚上。', '+3714245565028', 'RMB', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('210', '210', '0.0090', '32', '7', '在學生出身的官僚是。', '+3089692267481', 'RMB', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('211', '211', '0.0100', '79', '8', '篷的航船不是本家早。', '+6063271715813', 'RMB', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('212', '212', '0.0093', '31', '8', '不就是六斤的後背。', '+2931744680777', 'RMB', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('213', '213', '0.0005', '79', '8', '才的時候，給他碰了。', '+6882551986016', 'USD', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('214', '214', '0.0050', '46', '8', '法，伊歷來非常氣悶。', '+8999711822279', 'RMB', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('215', '215', '0.0080', '24', '8', '家偶然忘卻了。 即。', '+6454727320669', 'RMB', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('216', '216', '0.0010', '18', '8', '有以為這很像懇求掌。', '+5607728254293', 'USD', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('217', '217', '0.0015', '2', '8', '老生也難怪的閃起在。', '+7262724988961', 'USD', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('218', '218', '0.0080', '30', '8', '便正是一氣掘起四塊。', '+1648520588592', 'USD', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('219', '219', '0.0059', '41', '8', '阿Q忽然害怕起來了。', '+3515627021688', 'USD', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('220', '220', '0.0073', '88', '8', '辱之後，便稱之爲《。', '+9379060141858', 'RMB', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('221', '221', '0.0000', '55', '8', '子，他遲疑多時沒有。', '+6235732669857', 'RMB', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('222', '222', '0.0079', '43', '8', '的缺點，從十一點頭。', '+5087151790135', 'RMB', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('223', '223', '0.0027', '100', '8', '以買一碗飯，立刻知。', '+5813314990484', 'USD', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('224', '224', '0.0000', '61', '8', '後，秋風是一個很圓。', '+8739625845581', 'RMB', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('225', '225', '0.0100', '95', '8', '兩個指頭在小手的事。', '+1572216377202', 'RMB', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('226', '226', '0.0000', '66', '8', '舂米。蓬的車輛之外。', '+3061060796670', 'USD', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('227', '227', '0.0080', '10', '8', '管自己雇車罷，於是。', '+3433222489981', 'RMB', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('228', '228', '0.0074', '88', '8', '那裡所第一要示眾。', '+1941728631117', 'RMB', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('229', '229', '0.0010', '42', '8', '候，在臺柱子上來。', '+1988478560584', 'USD', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('230', '230', '0.0000', '9', '8', '上來。掌櫃正在不是。', '+6982095547789', 'USD', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('231', '231', '0.0061', '50', '8', '戰爭的時候的這一夜。', '+7396059559023', 'RMB', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('232', '232', '0.0085', '54', '8', '斥的，在壁上碰了四。', '+3394671640541', 'USD', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('233', '233', '0.0037', '99', '8', '但只化了九日，鄒七。', '+1559499998684', 'RMB', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('234', '234', '0.0011', '12', '8', '搶案就是這樣的黑狗。', '+8394522660805', 'USD', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('235', '235', '0.0084', '27', '8', '前鄙薄教員，後面罵。', '+1393732055997', 'RMB', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('236', '236', '0.0000', '83', '8', '于是愈有錢……秀才。', '+4157134536609', 'USD', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('237', '237', '0.0012', '33', '8', '年，得了許多站在洞。', '+2780497067242', 'RMB', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('238', '238', '0.0000', '68', '8', '來的時世是不偷，倘。', '+8305454328602', 'USD', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('239', '239', '0.0000', '27', '8', '抵擋他？」聽了「衙。', '+4395919305536', 'USD', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('240', '240', '0.0020', '44', '8', '遙遙」的。你便捏了。', '+5534169173987', 'RMB', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('241', '241', '0.0000', '8', '9', '礙似的敬畏忽而又自。', '+2693176516990', 'RMB', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('242', '242', '0.0095', '25', '9', '他，太陽卻還能幫同。', '+4493294575324', 'RMB', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('243', '243', '0.0000', '71', '9', '知道不能抹殺的，後。', '+5431757592617', 'RMB', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('244', '244', '0.0021', '31', '9', '苦吃，而這屋子越顯。', '+6329802244672', 'USD', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('245', '245', '0.0000', '72', '9', '沒有！」 但今天特。', '+8543105764106', 'USD', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('246', '246', '0.0014', '16', '9', '過兩弔錢，抬了頭直。', '+4910977294152', 'RMB', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('247', '247', '0.0000', '12', '9', '七嫂便將辮子很光的。', '+8298177197468', 'USD', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('248', '248', '0.0000', '96', '9', '來打折了本；不一會。', '+4495763876388', 'RMB', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('249', '249', '0.0000', '8', '9', '的病人的眼睛，原來。', '+6578251228533', 'USD', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('250', '250', '0.0000', '70', '9', '歷來連聽也未免要殺。', '+4421837565684', 'RMB', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('251', '251', '0.0100', '28', '9', '錢洋鬼子可惡的筆不。', '+8786824777730', 'USD', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('252', '252', '0.0092', '10', '9', '但也沒有什麼缺陷。', '+6396351880795', 'USD', '0', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('253', '253', '0.0048', '69', '9', '來，以為就要來了。', '+6243531124212', 'RMB', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('254', '254', '0.0000', '55', '9', '好了，疏疏朗朗的站。', '+8391882244953', 'USD', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('255', '255', '0.0000', '18', '9', '和別處，而況在屈辱。', '+1039564145526', 'USD', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('256', '256', '0.0064', '81', '9', '的響了之後，他的兒。', '+5954304902741', 'RMB', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('257', '257', '0.0096', '69', '9', '個少年有了主意了。', '+8430169303868', 'RMB', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('258', '258', '0.0100', '42', '9', '意他們光著頭皮去尋。', '+1100417663511', 'USD', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('259', '259', '0.0062', '31', '9', '要推文藝，于是想走。', '+9532744711775', 'USD', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('260', '260', '0.0027', '81', '9', '拾行李也略已齊集。', '+6346807928476', 'USD', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('261', '261', '0.0000', '35', '9', '子竟沒有見過城裏的。', '+3041024391141', 'USD', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('262', '262', '0.0000', '32', '9', '白光卻分明是生平第。', '+6503608150843', 'USD', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('263', '263', '0.0070', '2', '9', '顯點靈，要他熬夜。', '+4988154484822', 'RMB', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('264', '264', '0.0023', '97', '9', '纔疑心他或者就應該。', '+3739287692965', 'USD', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('265', '265', '0.0100', '59', '9', '來或者是春賽，是可。', '+7292082044876', 'RMB', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('266', '266', '0.0053', '64', '9', '掌櫃都笑嘻嘻的送出。', '+1111157839627', 'RMB', '1', '1', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('267', '267', '0.0000', '66', '9', '張著嘴唇，卻並不放。', '+2148206694785', 'RMB', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('268', '268', '0.0086', '33', '9', '得：「我可以都拿來。', '+3177951115549', 'USD', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('269', '269', '0.0070', '58', '9', '呼吸從平穩了不少。', '+5350744199433', 'USD', '0', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('270', '270', '0.0060', '85', '9', '且擱起，買賣怎樣的。', '+9952301238745', 'USD', '1', '0', '2019-01-11 16:42:01', '2019-01-11 16:42:01');
INSERT INTO `sms_log` VALUES ('271', '271', '0.0020', '92', '10', '一望無際的碧綠的西。', '+6330064990888', 'RMB', '0', '0', '2019-01-11 16:42:02', '2019-01-11 16:42:02');
INSERT INTO `sms_log` VALUES ('272', '272', '0.0052', '59', '10', '可是一通，卻又不是。', '+5791725896066', 'RMB', '0', '0', '2019-01-11 16:42:02', '2019-01-11 16:42:02');
INSERT INTO `sms_log` VALUES ('273', '273', '0.0000', '94', '10', '變他們。我今天的靠。', '+4283610455962', 'RMB', '1', '0', '2019-01-11 16:42:02', '2019-01-11 16:42:02');
INSERT INTO `sms_log` VALUES ('274', '274', '0.0088', '38', '10', '義，將腰一伸，咿咿。', '+4233422369410', 'USD', '0', '1', '2019-01-11 16:42:02', '2019-01-11 16:42:02');
INSERT INTO `sms_log` VALUES ('275', '275', '0.0000', '26', '10', '他確鑿聽到什麼可買。', '+1284057543026', 'RMB', '1', '1', '2019-01-11 16:42:02', '2019-01-11 16:42:02');
INSERT INTO `sms_log` VALUES ('276', '276', '0.0032', '12', '10', '出來了！” 阿Q又。', '+7050280318082', 'USD', '0', '0', '2019-01-11 16:42:02', '2019-01-11 16:42:02');
INSERT INTO `sms_log` VALUES ('277', '277', '0.0000', '94', '10', '長衫人物了。——我。', '+2320885917867', 'USD', '1', '0', '2019-01-11 16:42:02', '2019-01-11 16:42:02');
INSERT INTO `sms_log` VALUES ('278', '278', '0.0004', '85', '10', '命卻居然也可以看出。', '+7914474695710', 'RMB', '0', '1', '2019-01-11 16:42:02', '2019-01-11 16:42:02');
INSERT INTO `sms_log` VALUES ('279', '279', '0.0100', '6', '10', '的二十多個聽講者。', '+4157808535050', 'RMB', '0', '0', '2019-01-11 16:42:02', '2019-01-11 16:42:02');
INSERT INTO `sms_log` VALUES ('280', '280', '0.0062', '60', '10', '他接著便將筷子指著。', '+8790736772173', 'RMB', '1', '0', '2019-01-11 16:42:02', '2019-01-11 16:42:02');
INSERT INTO `sms_log` VALUES ('281', '281', '0.0066', '96', '10', '搭連賣給別人都滿嵌。', '+6104580598635', 'USD', '0', '1', '2019-01-11 16:42:02', '2019-01-11 16:42:02');
INSERT INTO `sms_log` VALUES ('282', '282', '0.0000', '12', '10', '的農夫。阿Q本來幾。', '+6341324664622', 'RMB', '0', '1', '2019-01-11 16:42:02', '2019-01-11 16:42:02');
INSERT INTO `sms_log` VALUES ('283', '283', '0.0041', '21', '10', '取下粉板上拭去了。', '+8186822351366', 'USD', '1', '0', '2019-01-11 16:42:02', '2019-01-11 16:42:02');
INSERT INTO `sms_log` VALUES ('284', '284', '0.0100', '58', '10', ' 阿Q看來，先說是。', '+2231489092270', 'USD', '1', '0', '2019-01-11 16:42:02', '2019-01-11 16:42:02');
INSERT INTO `sms_log` VALUES ('285', '285', '0.0020', '92', '10', ' 我於是不怕，而其。', '+9709210259842', 'RMB', '0', '1', '2019-01-11 16:42:02', '2019-01-11 16:42:02');
INSERT INTO `sms_log` VALUES ('286', '286', '0.0003', '86', '10', '早在忘卻了。倘在別。', '+1795381852505', 'USD', '1', '1', '2019-01-11 16:42:02', '2019-01-11 16:42:02');
INSERT INTO `sms_log` VALUES ('287', '287', '0.0000', '10', '10', '滅亡。” 許多熟睡。', '+1890483172828', 'USD', '0', '1', '2019-01-11 16:42:02', '2019-01-11 16:42:02');
INSERT INTO `sms_log` VALUES ('288', '288', '0.0002', '9', '10', '不安模樣，更與平常。', '+1725961138990', 'RMB', '1', '0', '2019-01-11 16:42:02', '2019-01-11 16:42:02');
INSERT INTO `sms_log` VALUES ('289', '289', '0.0000', '51', '10', '也是阿Q便迎上去較。', '+5065479830399', 'USD', '0', '1', '2019-01-11 16:42:02', '2019-01-11 16:42:02');
INSERT INTO `sms_log` VALUES ('290', '290', '0.0010', '65', '10', '都悚然而不能抹殺的。', '+4997071191986', 'USD', '1', '0', '2019-01-11 16:42:02', '2019-01-11 16:42:02');
INSERT INTO `sms_log` VALUES ('291', '291', '0.0035', '81', '10', '見底，卻也希望，忽。', '+6352689207903', 'RMB', '1', '1', '2019-01-11 16:42:02', '2019-01-11 16:42:02');
INSERT INTO `sms_log` VALUES ('292', '292', '0.0079', '5', '10', '東西。有一個老漁父。', '+8075699001990', 'USD', '1', '0', '2019-01-11 16:42:02', '2019-01-11 16:42:02');
INSERT INTO `sms_log` VALUES ('293', '293', '0.0000', '3', '10', '了腰，在我面前只剩。', '+4158967078197', 'USD', '1', '1', '2019-01-11 16:42:02', '2019-01-11 16:42:02');
INSERT INTO `sms_log` VALUES ('294', '294', '0.0000', '12', '10', '氣，又使他有這麼薄。', '+8531297980487', 'RMB', '1', '1', '2019-01-11 16:42:02', '2019-01-11 16:42:02');
INSERT INTO `sms_log` VALUES ('295', '295', '0.0080', '61', '10', '的酒店的。不管人家。', '+2305328663460', 'USD', '1', '1', '2019-01-11 16:42:02', '2019-01-11 16:42:02');
INSERT INTO `sms_log` VALUES ('296', '296', '0.0086', '61', '10', '其間，直紮下去，在。', '+5335074138214', 'USD', '0', '1', '2019-01-11 16:42:02', '2019-01-11 16:42:02');
INSERT INTO `sms_log` VALUES ('297', '297', '0.0088', '34', '10', '大聲的叫喊于生人並。', '+7002105169727', 'USD', '0', '1', '2019-01-11 16:42:02', '2019-01-11 16:42:02');
INSERT INTO `sms_log` VALUES ('298', '298', '0.0000', '63', '10', '拖著吳媽，似乎仿佛。', '+6901573090544', 'RMB', '0', '0', '2019-01-11 16:42:02', '2019-01-11 16:42:02');
INSERT INTO `sms_log` VALUES ('299', '299', '0.0072', '75', '10', '什麼來就因為後來纔。', '+9148567041648', 'RMB', '1', '1', '2019-01-11 16:42:02', '2019-01-11 16:42:02');
INSERT INTO `sms_log` VALUES ('300', '300', '0.0063', '47', '10', '教員的薪水欠到大半。', '+3973438189832', 'USD', '1', '0', '2019-01-11 16:42:02', '2019-01-11 16:42:02');

-- ----------------------------
-- Table structure for `sms_template`
-- ----------------------------
DROP TABLE IF EXISTS `sms_template`;
CREATE TABLE `sms_template` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account_id` int(11) NOT NULL COMMENT '帳號的 id',
  `provider_template_id` int(11) NOT NULL COMMENT '廠商上的模板 id ',
  `content` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '短信模板內容',
  `rule` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '變數內容，用，分隔',
  `rule_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '變數標題，用，分隔',
  `sign` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '簽名檔',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL COMMENT '可能被禁用的模板',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of sms_template
-- ----------------------------
INSERT INTO `sms_template` VALUES ('1', '1', '1226249', '磨的鐵鏡罷了，這也。', '#account#,#package#,#name#', '帳號,包裹名稱,名字', '[ 紫光 ]', '2019-01-11 16:42:00', '2019-01-11 16:42:00', null);
INSERT INTO `sms_template` VALUES ('2', '1', '806648', '前，眼光，忽然揚起。', '#name#,#package#', '名字,包裹名稱', '[ 紫光 ]', '2019-01-11 16:42:00', '2019-01-11 16:42:00', null);
INSERT INTO `sms_template` VALUES ('3', '2', '302077', '馬路上走，人們都不。', '#name#', '名字', '[ 紫光 ]', '2019-01-11 16:42:00', '2019-01-11 16:42:00', null);
INSERT INTO `sms_template` VALUES ('4', '2', '468129', '以他的景況也很快意。', '#account#,#package#,#name#', '帳號,包裹名稱,名字', '[ 蘋果 ]', '2019-01-11 16:42:00', '2019-01-11 16:42:00', null);
INSERT INTO `sms_template` VALUES ('5', '3', '1045810', '得去看。再往上仔細。', '#name#,#package#', '名字,包裹名稱', '[ 紫光 ]', '2019-01-11 16:42:00', '2019-01-11 16:42:00', null);
INSERT INTO `sms_template` VALUES ('6', '3', '660585', '時候來給一定想引誘。', '#name#', '名字', '[ 蘋果 ]', '2019-01-11 16:42:00', '2019-01-11 16:42:00', null);
INSERT INTO `sms_template` VALUES ('7', '4', '43888', '總是崇拜偶像，我也。', '#account#,#package#,#name#', '帳號,包裹名稱,名字', '[ 蘋果 ]', '2019-01-11 16:42:01', '2019-01-11 16:42:01', null);
INSERT INTO `sms_template` VALUES ('8', '4', '232269', '說這是與其慢也寧敬。', '#account#', '帳號', '[ 紫光 ]', '2019-01-11 16:42:01', '2019-01-11 16:42:01', null);
INSERT INTO `sms_template` VALUES ('9', '5', '1047219', '是因為其時臺下滿是。', '#account#,#package#,#name#', '帳號,包裹名稱,名字', '[ 紫光 ]', '2019-01-11 16:42:01', '2019-01-11 16:42:01', null);
INSERT INTO `sms_template` VALUES ('10', '5', '1226170', '仔細看時又被王胡之。', '#name#,#package#', '名字,包裹名稱', '[ 紫光 ]', '2019-01-11 16:42:01', '2019-01-11 16:42:01', null);
INSERT INTO `sms_template` VALUES ('11', '6', '1153184', '外倒運的神情。「迅。', '#name#,#account#', '名字,帳號', '[ 紫光 ]', '2019-01-11 16:42:01', '2019-01-11 16:42:01', null);
INSERT INTO `sms_template` VALUES ('12', '6', '933715', '然高壽，耳朵只在過。', '#package#', '包裹名稱', '[ 紫光 ]', '2019-01-11 16:42:01', '2019-01-11 16:42:01', null);
INSERT INTO `sms_template` VALUES ('13', '7', '429590', '得很遲，是一件新聞。', '#name#,#account#', '名字,帳號', '[ 紫光 ]', '2019-01-11 16:42:01', '2019-01-11 16:42:01', null);
INSERT INTO `sms_template` VALUES ('14', '7', '722625', '有零的時候似的說。', '#name#,#account#', '名字,帳號', '[ 蘋果 ]', '2019-01-11 16:42:01', '2019-01-11 16:42:01', null);
INSERT INTO `sms_template` VALUES ('15', '8', '586119', '常感激的謝他。他的。', '#account#', '帳號', '[ 蘋果 ]', '2019-01-11 16:42:01', '2019-01-11 16:42:01', null);
INSERT INTO `sms_template` VALUES ('16', '8', '388337', '件傢具，木器腳。這。', '#name#,#package#', '名字,包裹名稱', '[ 紫光 ]', '2019-01-11 16:42:01', '2019-01-11 16:42:01', null);
INSERT INTO `sms_template` VALUES ('17', '9', '700475', '面趕快縮了頭，但最。', '#package#', '包裹名稱', '[ 紫光 ]', '2019-01-11 16:42:01', '2019-01-11 16:42:01', null);
INSERT INTO `sms_template` VALUES ('18', '9', '472131', '得背後。 但阿Q想。', '#package#', '包裹名稱', '[ 蘋果 ]', '2019-01-11 16:42:01', '2019-01-11 16:42:01', null);
INSERT INTO `sms_template` VALUES ('19', '10', '92091', '收的扇動。 我素不。', '#package#', '包裹名稱', '[ 蘋果 ]', '2019-01-11 16:42:01', '2019-01-11 16:42:01', null);
INSERT INTO `sms_template` VALUES ('20', '10', '55900', '時候，天要下來逃難。', '#package#', '包裹名稱', '[ 紫光 ]', '2019-01-11 16:42:02', '2019-01-11 16:42:01', null);

-- ----------------------------
-- Table structure for `telephone_task_maintain`
-- ----------------------------
DROP TABLE IF EXISTS `telephone_task_maintain`;
CREATE TABLE `telephone_task_maintain` (
  `member_id` int(10) unsigned NOT NULL COMMENT '會員 id',
  `promoter_id` int(10) unsigned NOT NULL COMMENT '指派專員 id',
  `task_id` int(11) DEFAULT NULL COMMENT '任務 id',
  `start_call` datetime DEFAULT NULL COMMENT '任務第一次的開始時間，不管幾次',
  `end_call` datetime DEFAULT NULL COMMENT '任務最後一次的結束時間，不管幾次',
  `status` tinyint(3) unsigned NOT NULL DEFAULT 1 COMMENT '0 隱藏,1 顯示',
  `duration` int(10) unsigned NOT NULL DEFAULT 0 COMMENT '任務累計總時長，不分次數，單位秒',
  `sms_id` int(11) NOT NULL DEFAULT 0 COMMENT '當前任務短信 id'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of telephone_task_maintain
-- ----------------------------
INSERT INTO `telephone_task_maintain` VALUES ('1', '71', '2', null, null, '1', '0', '0');
INSERT INTO `telephone_task_maintain` VALUES ('2', '71', '2', null, null, '1', '0', '0');
INSERT INTO `telephone_task_maintain` VALUES ('3', '71', '2', null, null, '1', '0', '0');
INSERT INTO `telephone_task_maintain` VALUES ('4', '71', '2', null, null, '1', '0', '0');
INSERT INTO `telephone_task_maintain` VALUES ('5', '71', '2', null, null, '1', '0', '0');
INSERT INTO `telephone_task_maintain` VALUES ('6', '71', '2', null, null, '1', '0', '0');
INSERT INTO `telephone_task_maintain` VALUES ('7', '71', '2', null, null, '1', '0', '0');
INSERT INTO `telephone_task_maintain` VALUES ('8', '71', '2', null, null, '1', '0', '0');
INSERT INTO `telephone_task_maintain` VALUES ('9', '71', '2', null, null, '1', '0', '0');
INSERT INTO `telephone_task_maintain` VALUES ('10', '71', '2', null, null, '1', '0', '0');

-- ----------------------------
-- Table structure for `themes`
-- ----------------------------
DROP TABLE IF EXISTS `themes`;
CREATE TABLE `themes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pc` tinyint(1) NOT NULL DEFAULT 0,
  `mobile` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `display_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `themes_name_index` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of themes
-- ----------------------------
INSERT INTO `themes` VALUES ('1', 'default', '1', '1', null, null, '主站', null);
INSERT INTO `themes` VALUES ('2', 'slots2017', '1', '0', null, null, '電子遊藝站2017', null);
INSERT INTO `themes` VALUES ('3', 'landingPage2016', '0', '1', null, null, '引導頁2016', null);
INSERT INTO `themes` VALUES ('4', 'alternatePage', '1', '1', null, null, '備用域名', null);

-- ----------------------------
-- Table structure for `theme_website`
-- ----------------------------
DROP TABLE IF EXISTS `theme_website`;
CREATE TABLE `theme_website` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `domain` char(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `theme_id` int(10) unsigned NOT NULL,
  `pc` tinyint(1) NOT NULL DEFAULT 0,
  `mobile` tinyint(1) NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `theme_website_theme_id_index` (`theme_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of theme_website
-- ----------------------------

-- ----------------------------
-- Table structure for `tm_admin_extra_info`
-- ----------------------------
DROP TABLE IF EXISTS `tm_admin_extra_info`;
CREATE TABLE `tm_admin_extra_info` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `admin_id` int(10) unsigned NOT NULL COMMENT '管理id',
  `qq` int(11) DEFAULT NULL COMMENT '人員的qq號碼 (純數字)',
  `wechat` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '人員的微信id (字母,數字,下滑線)',
  `sip_agent_id` int(11) DEFAULT NULL COMMENT 'voip 的坐席號',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1001 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of tm_admin_extra_info
-- ----------------------------
INSERT INTO `tm_admin_extra_info` VALUES ('1', '1', '131501', '199061', '907', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('2', '2', '817965', '557339', '913', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('3', '3', '503131', '832695', '915', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('4', '4', '832434', '417783', '901', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('5', '5', '137349', '488160', '915', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('6', '6', '116941', '423913', '902', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('7', '7', '896225', '369327', '903', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('8', '8', '921017', '999777', '905', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('9', '9', '918630', '432236', '911', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('10', '10', '880328', '877936', '917', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('11', '11', '938629', '446987', '906', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('12', '12', '464295', '617155', '906', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('13', '13', '631044', '215075', '902', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('14', '14', '851987', '502459', '907', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('15', '15', '276693', '616373', '903', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('16', '16', '296694', '298936', '907', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('17', '17', '717906', '488101', '908', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('18', '18', '888858', '637769', '907', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('19', '19', '887753', '579872', '916', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('20', '20', '954722', '152169', '909', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('21', '21', '572969', '328734', '901', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('22', '22', '847902', '728951', '906', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('23', '23', '500984', '863852', '909', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('24', '24', '387973', '945867', '916', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('25', '25', '194953', '245157', '904', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('26', '26', '380220', '510006', '912', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('27', '27', '108825', '414877', '919', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('28', '28', '655006', '464480', '915', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('29', '29', '225327', '400530', '908', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('30', '30', '179617', '648644', '911', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('31', '31', '677163', '522955', '905', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('32', '32', '811948', '885677', '912', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('33', '33', '374053', '356060', '912', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('34', '34', '152486', '640825', '913', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('35', '35', '780122', '453437', '908', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('36', '36', '768264', '133636', '919', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('37', '37', '252144', '679525', '909', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('38', '38', '774157', '423059', '915', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('39', '39', '382353', '452381', '902', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('40', '40', '463612', '614325', '904', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('41', '41', '213135', '501987', '916', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('42', '42', '765408', '892712', '908', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('43', '43', '574789', '212163', '901', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('44', '44', '353775', '151455', '903', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('45', '45', '329395', '304789', '919', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('46', '46', '230816', '940479', '916', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('47', '47', '313623', '510896', '916', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('48', '48', '230286', '431848', '909', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('49', '49', '573916', '825619', '902', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('50', '50', '616782', '429661', '905', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('51', '51', '762263', '529860', '903', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('52', '52', '783565', '666539', '910', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('53', '53', '345660', '677528', '905', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('54', '54', '180256', '685756', '908', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('55', '55', '211216', '377424', '919', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('56', '56', '923739', '405068', '919', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('57', '57', '836129', '326256', '912', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('58', '58', '979684', '541987', '919', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('59', '59', '495307', '793682', '901', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('60', '60', '284649', '835408', '915', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('61', '61', '268579', '758315', '903', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('62', '62', '859620', '504884', '906', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('63', '63', '108013', '201691', '917', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('64', '64', '351291', '601324', '905', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('65', '65', '972136', '161965', '909', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('66', '66', '614591', '675042', '906', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('67', '67', '616464', '121601', '919', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('68', '68', '625273', '328126', '918', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('69', '69', '448441', '133140', '913', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('70', '70', '177290', '269649', '919', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('71', '71', '587673', '653532', '915', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('72', '72', '823445', '377537', '906', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('73', '73', '712889', '339904', '915', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('74', '74', '433787', '368068', '914', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('75', '75', '504669', '774694', '911', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('76', '76', '881713', '853389', '907', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('77', '77', '123762', '633797', '913', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('78', '78', '270766', '971449', '915', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('79', '79', '812891', '420058', '912', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('80', '80', '289271', '435671', '919', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('81', '81', '321897', '918326', '908', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('82', '82', '727816', '928986', '916', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('83', '83', '325585', '222513', '913', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('84', '84', '613567', '303361', '917', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('85', '85', '481483', '404389', '907', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('86', '86', '278307', '655820', '910', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('87', '87', '743179', '292189', '917', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('88', '88', '155892', '627131', '908', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('89', '89', '319523', '995572', '911', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('90', '90', '120846', '215879', '915', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('91', '91', '109405', '285010', '917', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('92', '92', '638405', '106844', '911', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('93', '93', '827270', '669753', '908', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('94', '94', '123567', '364020', '916', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('95', '95', '635808', '693487', '907', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('96', '96', '410989', '488248', '914', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('97', '97', '706576', '692585', '905', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('98', '98', '210394', '673246', '914', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('99', '99', '367737', '303987', '903', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('100', '100', '569335', '732007', '901', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('101', '101', '797115', '307408', '904', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('102', '102', '598621', '160869', '910', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('103', '103', '109949', '753853', '902', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('104', '104', '895446', '994037', '910', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('105', '105', '626128', '447005', '909', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('106', '106', '185015', '411216', '906', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('107', '107', '804998', '983848', '911', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('108', '108', '994586', '470756', '907', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('109', '109', '228807', '236110', '913', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('110', '110', '449418', '420349', '912', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('111', '111', '816341', '678493', '905', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('112', '112', '263889', '212962', '908', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('113', '113', '719467', '982315', '919', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('114', '114', '423329', '918911', '915', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('115', '115', '479243', '414512', '910', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('116', '116', '963899', '503321', '909', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('117', '117', '834095', '517747', '907', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('118', '118', '192722', '369786', '910', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('119', '119', '482963', '636849', '910', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('120', '120', '925502', '516105', '912', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('121', '121', '108185', '372929', '916', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('122', '122', '589615', '887674', '914', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('123', '123', '955212', '978942', '901', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('124', '124', '517600', '117830', '914', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('125', '125', '570241', '846043', '905', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('126', '126', '465558', '628017', '914', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('127', '127', '821959', '188826', '910', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('128', '128', '222313', '505941', '917', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('129', '129', '558431', '625468', '907', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('130', '130', '684977', '698041', '915', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('131', '131', '427553', '953591', '902', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('132', '132', '286170', '724820', '904', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('133', '133', '961573', '301784', '905', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('134', '134', '609818', '432337', '912', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('135', '135', '435335', '864291', '901', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('136', '136', '617983', '439791', '913', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('137', '137', '615966', '673491', '911', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('138', '138', '360205', '463534', '911', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('139', '139', '602458', '678224', '905', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('140', '140', '726121', '812265', '914', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('141', '141', '103847', '382057', '909', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('142', '142', '538925', '946914', '905', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('143', '143', '721180', '574682', '903', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('144', '144', '252286', '870341', '907', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('145', '145', '929076', '164280', '910', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('146', '146', '982085', '904530', '918', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('147', '147', '761694', '731253', '904', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('148', '148', '223941', '257541', '904', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('149', '149', '482800', '614046', '905', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('150', '150', '855577', '341000', '910', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('151', '151', '668377', '383352', '907', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('152', '152', '676699', '289556', '910', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('153', '153', '628032', '561188', '909', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('154', '154', '486420', '219449', '901', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('155', '155', '625396', '177956', '909', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('156', '156', '849578', '758187', '902', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('157', '157', '161992', '522043', '907', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('158', '158', '665194', '504422', '908', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('159', '159', '958258', '872619', '916', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('160', '160', '406293', '910762', '918', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('161', '161', '390078', '623075', '918', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('162', '162', '175754', '764664', '917', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('163', '163', '220882', '601114', '911', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('164', '164', '728287', '891778', '904', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('165', '165', '764997', '696414', '917', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('166', '166', '172193', '872493', '918', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('167', '167', '459625', '995244', '912', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('168', '168', '150069', '706077', '918', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('169', '169', '988752', '459281', '910', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('170', '170', '827858', '499212', '902', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('171', '171', '254751', '646432', '919', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('172', '172', '207293', '207507', '917', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('173', '173', '327833', '990898', '911', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('174', '174', '994845', '634689', '911', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('175', '175', '375959', '523813', '919', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('176', '176', '840725', '306320', '903', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('177', '177', '103298', '149566', '917', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('178', '178', '406672', '654396', '908', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('179', '179', '306704', '155533', '916', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('180', '180', '333737', '363873', '918', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('181', '181', '609839', '382008', '916', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('182', '182', '897384', '707766', '906', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('183', '183', '171879', '323426', '906', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('184', '184', '286915', '599818', '918', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('185', '185', '224867', '495367', '917', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('186', '186', '752618', '805861', '915', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('187', '187', '832187', '352221', '918', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('188', '188', '170374', '378180', '908', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('189', '189', '630080', '692964', '914', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('190', '190', '272235', '907646', '911', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('191', '191', '750889', '720730', '906', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('192', '192', '288290', '412637', '901', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('193', '193', '721529', '417191', '915', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('194', '194', '514321', '934591', '902', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('195', '195', '406897', '420030', '906', '2019-01-11 16:41:58', '2019-01-11 16:41:58');
INSERT INTO `tm_admin_extra_info` VALUES ('196', '196', '240319', '181346', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('197', '197', '787045', '632152', '901', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('198', '198', '858437', '884554', '911', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('199', '199', '659281', '644276', '916', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('200', '200', '788410', '112468', '910', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('201', '201', '776786', '475339', '911', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('202', '202', '617415', '100118', '907', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('203', '203', '124101', '454500', '902', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('204', '204', '598814', '125548', '909', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('205', '205', '687945', '555554', '913', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('206', '206', '826470', '963208', '907', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('207', '207', '150644', '809262', '911', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('208', '208', '774729', '846556', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('209', '209', '160678', '838745', '919', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('210', '210', '723089', '603265', '919', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('211', '211', '788145', '493338', '916', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('212', '212', '145238', '535034', '919', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('213', '213', '978280', '964912', '904', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('214', '214', '601831', '490508', '907', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('215', '215', '160471', '666254', '918', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('216', '216', '749966', '501991', '912', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('217', '217', '661949', '803095', '908', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('218', '218', '581550', '961171', '912', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('219', '219', '119176', '314365', '912', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('220', '220', '232361', '286580', '909', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('221', '221', '228908', '467004', '904', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('222', '222', '513457', '476327', '911', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('223', '223', '249202', '843458', '906', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('224', '224', '349249', '455883', '909', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('225', '225', '870732', '700243', '913', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('226', '226', '235413', '914318', '910', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('227', '227', '291248', '576076', '909', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('228', '228', '694282', '294288', '901', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('229', '229', '552846', '319612', '916', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('230', '230', '335830', '416852', '916', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('231', '231', '701842', '784265', '916', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('232', '232', '550748', '453487', '916', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('233', '233', '956702', '349393', '911', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('234', '234', '642506', '318841', '901', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('235', '235', '236890', '762009', '915', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('236', '236', '629764', '999658', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('237', '237', '496957', '838771', '918', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('238', '238', '202904', '828736', '906', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('239', '239', '738912', '197987', '914', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('240', '240', '237885', '463266', '908', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('241', '241', '943978', '521157', '907', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('242', '242', '325482', '278255', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('243', '243', '114718', '885776', '911', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('244', '244', '457111', '426850', '919', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('245', '245', '781453', '701066', '901', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('246', '246', '526010', '325046', '901', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('247', '247', '547716', '202868', '914', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('248', '248', '554851', '517541', '908', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('249', '249', '772053', '502903', '916', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('250', '250', '183453', '635488', '903', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('251', '251', '702105', '616670', '912', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('252', '252', '472304', '134410', '913', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('253', '253', '486652', '283021', '914', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('254', '254', '286563', '497359', '919', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('255', '255', '473404', '427247', '902', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('256', '256', '673768', '899925', '917', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('257', '257', '688071', '704153', '901', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('258', '258', '894197', '455981', '918', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('259', '259', '967655', '396731', '901', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('260', '260', '651446', '810176', '914', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('261', '261', '573076', '956798', '904', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('262', '262', '446713', '224127', '901', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('263', '263', '146997', '674320', '918', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('264', '264', '124921', '126677', '906', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('265', '265', '803793', '528162', '902', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('266', '266', '858909', '605164', '914', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('267', '267', '248185', '195880', '911', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('268', '268', '620607', '173201', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('269', '269', '809257', '976483', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('270', '270', '209891', '753219', '903', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('271', '271', '507155', '330519', '919', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('272', '272', '119681', '544093', '912', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('273', '273', '636376', '723796', '919', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('274', '274', '421863', '785372', '917', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('275', '275', '290087', '584185', '913', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('276', '276', '248637', '234633', '914', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('277', '277', '905856', '993957', '910', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('278', '278', '560982', '334757', '917', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('279', '279', '101471', '207324', '912', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('280', '280', '224001', '806264', '909', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('281', '281', '958583', '590406', '909', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('282', '282', '626659', '985296', '908', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('283', '283', '406356', '487947', '910', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('284', '284', '759212', '859818', '914', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('285', '285', '314946', '319278', '919', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('286', '286', '454702', '833313', '911', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('287', '287', '568893', '456317', '911', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('288', '288', '778163', '606877', '907', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('289', '289', '139441', '377161', '919', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('290', '290', '437184', '183432', '903', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('291', '291', '754684', '836593', '903', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('292', '292', '821818', '668977', '910', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('293', '293', '640260', '571147', '909', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('294', '294', '226587', '314175', '908', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('295', '295', '214560', '596683', '915', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('296', '296', '134048', '472296', '918', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('297', '297', '609725', '310424', '908', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('298', '298', '164098', '697449', '919', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('299', '299', '923403', '797767', '909', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('300', '300', '795335', '858999', '902', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('301', '301', '662989', '706164', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('302', '302', '581431', '511644', '908', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('303', '303', '221221', '643834', '908', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('304', '304', '201844', '353350', '911', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('305', '305', '598024', '981496', '904', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('306', '306', '418230', '387493', '914', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('307', '307', '272175', '960661', '918', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('308', '308', '511578', '471872', '913', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('309', '309', '232930', '625614', '910', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('310', '310', '391694', '517907', '901', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('311', '311', '391691', '413487', '901', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('312', '312', '235725', '990666', '910', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('313', '313', '697494', '290159', '918', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('314', '314', '143897', '533467', '903', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('315', '315', '577516', '494113', '915', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('316', '316', '169702', '741039', '910', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('317', '317', '733370', '197299', '915', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('318', '318', '384645', '882701', '902', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('319', '319', '744595', '263229', '909', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('320', '320', '506726', '606521', '917', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('321', '321', '496560', '785694', '908', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('322', '322', '669522', '875312', '904', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('323', '323', '238260', '976358', '918', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('324', '324', '502340', '994928', '903', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('325', '325', '712942', '121886', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('326', '326', '943786', '568209', '914', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('327', '327', '890154', '564194', '901', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('328', '328', '598118', '894207', '917', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('329', '329', '139602', '739636', '912', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('330', '330', '215835', '376834', '911', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('331', '331', '243168', '190734', '917', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('332', '332', '215215', '812769', '918', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('333', '333', '231052', '539590', '903', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('334', '334', '117920', '825390', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('335', '335', '472789', '601576', '917', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('336', '336', '353449', '121549', '907', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('337', '337', '335159', '641140', '908', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('338', '338', '168542', '882849', '907', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('339', '339', '191400', '171003', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('340', '340', '420903', '860560', '910', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('341', '341', '909778', '657681', '916', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('342', '342', '235987', '863677', '908', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('343', '343', '456285', '936320', '902', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('344', '344', '909654', '969051', '902', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('345', '345', '171211', '260767', '906', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('346', '346', '490507', '905702', '907', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('347', '347', '159670', '312153', '904', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('348', '348', '572157', '560028', '915', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('349', '349', '833414', '629987', '914', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('350', '350', '573975', '363869', '902', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('351', '351', '892281', '544129', '909', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('352', '352', '501067', '191607', '912', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('353', '353', '764448', '144787', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('354', '354', '844827', '651704', '913', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('355', '355', '793253', '259415', '918', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('356', '356', '321257', '968191', '910', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('357', '357', '710374', '200515', '915', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('358', '358', '235276', '209527', '916', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('359', '359', '765847', '538198', '907', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('360', '360', '934739', '362756', '911', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('361', '361', '901832', '255368', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('362', '362', '603407', '140378', '903', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('363', '363', '706954', '987243', '908', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('364', '364', '451208', '146993', '914', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('365', '365', '857395', '985215', '916', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('366', '366', '840932', '256767', '908', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('367', '367', '420073', '447381', '916', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('368', '368', '807112', '937705', '915', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('369', '369', '517402', '290953', '910', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('370', '370', '745422', '389907', '906', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('371', '371', '752081', '394992', '919', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('372', '372', '336677', '514858', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('373', '373', '876552', '334032', '912', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('374', '374', '863295', '694296', '912', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('375', '375', '985136', '303015', '907', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('376', '376', '142217', '539482', '917', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('377', '377', '472678', '950769', '919', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('378', '378', '350443', '682443', '915', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('379', '379', '647591', '510111', '914', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('380', '380', '752654', '138709', '913', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('381', '381', '844679', '103579', '902', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('382', '382', '463466', '383966', '911', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('383', '383', '859617', '208995', '916', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('384', '384', '696213', '952955', '909', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('385', '385', '432965', '158289', '904', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('386', '386', '487369', '205939', '912', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('387', '387', '856166', '186280', '919', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('388', '388', '435192', '414816', '901', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('389', '389', '295529', '209856', '913', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('390', '390', '637263', '920579', '903', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('391', '391', '793134', '616783', '918', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('392', '392', '543724', '715246', '913', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('393', '393', '630462', '558809', '913', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('394', '394', '781618', '956889', '906', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('395', '395', '734840', '326749', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('396', '396', '374201', '350967', '914', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('397', '397', '361363', '893251', '907', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('398', '398', '535971', '694216', '917', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('399', '399', '681624', '656326', '906', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('400', '400', '947369', '326677', '904', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('401', '401', '892027', '562034', '916', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('402', '402', '700630', '816011', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('403', '403', '111872', '559980', '917', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('404', '404', '378015', '139673', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('405', '405', '554736', '988332', '916', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('406', '406', '387974', '915140', '909', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('407', '407', '585830', '830279', '916', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('408', '408', '180601', '830910', '914', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('409', '409', '821827', '883654', '907', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('410', '410', '407670', '371833', '914', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('411', '411', '824029', '414474', '902', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('412', '412', '949644', '944210', '912', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('413', '413', '328716', '392101', '914', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('414', '414', '108812', '894357', '914', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('415', '415', '592612', '447342', '918', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('416', '416', '790366', '557924', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('417', '417', '127586', '191832', '917', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('418', '418', '514556', '405359', '907', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('419', '419', '116466', '125426', '919', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('420', '420', '684261', '755974', '908', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('421', '421', '691446', '240198', '919', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('422', '422', '798677', '780016', '906', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('423', '423', '433623', '832506', '911', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('424', '424', '231646', '760301', '909', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('425', '425', '542494', '439772', '910', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('426', '426', '967183', '228216', '916', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('427', '427', '630210', '116910', '902', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('428', '428', '829420', '713310', '914', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('429', '429', '963585', '696107', '918', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('430', '430', '663726', '520400', '906', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('431', '431', '383637', '552326', '902', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('432', '432', '228843', '237882', '912', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('433', '433', '950045', '530869', '904', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('434', '434', '793223', '576023', '912', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('435', '435', '824941', '436157', '911', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('436', '436', '517312', '886080', '906', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('437', '437', '453422', '332692', '917', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('438', '438', '510693', '148553', '910', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('439', '439', '387253', '961597', '904', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('440', '440', '174036', '221201', '901', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('441', '441', '106188', '424552', '910', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('442', '442', '380728', '678176', '914', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('443', '443', '555860', '711061', '914', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('444', '444', '676100', '296043', '908', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('445', '445', '406370', '122594', '907', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('446', '446', '677360', '811715', '911', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('447', '447', '234304', '842137', '911', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('448', '448', '122556', '227584', '918', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('449', '449', '470705', '411843', '917', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('450', '450', '576515', '103657', '911', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('451', '451', '994741', '876133', '907', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('452', '452', '661202', '226003', '907', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('453', '453', '781502', '222122', '901', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('454', '454', '308431', '334603', '909', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('455', '455', '528844', '314239', '916', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('456', '456', '606080', '812256', '906', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('457', '457', '208632', '326947', '912', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('458', '458', '640921', '120483', '911', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('459', '459', '248604', '136755', '912', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('460', '460', '726698', '761470', '915', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('461', '461', '198074', '246452', '903', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('462', '462', '925542', '417684', '902', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('463', '463', '968055', '633335', '911', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('464', '464', '917028', '232748', '901', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('465', '465', '191012', '384796', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('466', '466', '486318', '484461', '918', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('467', '467', '531589', '366066', '909', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('468', '468', '235157', '612816', '901', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('469', '469', '584565', '267686', '912', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('470', '470', '762157', '313085', '904', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('471', '471', '282314', '431181', '903', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('472', '472', '536954', '294766', '903', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('473', '473', '202863', '563939', '912', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('474', '474', '862740', '858788', '904', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('475', '475', '257304', '663650', '915', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('476', '476', '100958', '524019', '902', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('477', '477', '914596', '914823', '918', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('478', '478', '386524', '164585', '907', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('479', '479', '281977', '963768', '917', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('480', '480', '238900', '259328', '902', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('481', '481', '847956', '346741', '919', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('482', '482', '922512', '171851', '912', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('483', '483', '585119', '149935', '915', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('484', '484', '512451', '143028', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('485', '485', '767554', '971423', '910', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('486', '486', '890337', '888584', '904', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('487', '487', '548174', '442466', '915', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('488', '488', '562395', '790095', '903', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('489', '489', '674069', '992892', '903', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('490', '490', '741014', '627067', '914', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('491', '491', '882132', '616497', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('492', '492', '161719', '551568', '913', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('493', '493', '907673', '992163', '909', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('494', '494', '519027', '722896', '906', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('495', '495', '433682', '239412', '914', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('496', '496', '533717', '475099', '906', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('497', '497', '938769', '604528', '906', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('498', '498', '726010', '800093', '913', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('499', '499', '162496', '648902', '911', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('500', '500', '711601', '721133', '915', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('501', '501', '294949', '200164', '903', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('502', '502', '896993', '642626', '914', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('503', '503', '576260', '591259', '907', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('504', '504', '955524', '684052', '910', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('505', '505', '643278', '101401', '915', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('506', '506', '709630', '958256', '910', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('507', '507', '960594', '499615', '901', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('508', '508', '998549', '867174', '904', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('509', '509', '683400', '779493', '913', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('510', '510', '536654', '674188', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('511', '511', '504537', '855639', '918', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('512', '512', '991705', '158295', '909', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('513', '513', '885902', '354413', '906', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('514', '514', '174121', '625235', '909', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('515', '515', '476979', '189094', '914', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('516', '516', '552936', '780690', '909', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('517', '517', '665947', '203413', '918', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('518', '518', '658983', '622369', '910', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('519', '519', '968518', '567377', '914', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('520', '520', '172441', '732837', '916', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('521', '521', '989477', '955696', '902', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('522', '522', '179649', '497483', '910', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('523', '523', '553296', '290783', '912', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('524', '524', '659266', '504747', '906', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('525', '525', '931784', '662676', '916', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('526', '526', '930091', '348800', '903', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('527', '527', '411701', '179234', '907', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('528', '528', '617049', '344643', '918', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('529', '529', '600667', '809331', '915', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('530', '530', '666468', '600332', '907', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('531', '531', '949236', '753959', '911', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('532', '532', '271244', '732090', '913', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('533', '533', '472089', '454501', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('534', '534', '585959', '472784', '916', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('535', '535', '132002', '168837', '909', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('536', '536', '577717', '291483', '912', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('537', '537', '452236', '408852', '907', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('538', '538', '872076', '545655', '915', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('539', '539', '193086', '577666', '903', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('540', '540', '864743', '825680', '907', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('541', '541', '320225', '775494', '912', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('542', '542', '512886', '128639', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('543', '543', '598201', '638936', '918', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('544', '544', '499338', '598332', '917', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('545', '545', '667332', '404516', '902', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('546', '546', '370632', '532671', '904', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('547', '547', '894158', '886333', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('548', '548', '556795', '436071', '912', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('549', '549', '789895', '729151', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('550', '550', '141507', '479364', '903', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('551', '551', '793596', '578835', '904', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('552', '552', '680256', '710536', '910', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('553', '553', '596243', '895817', '904', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('554', '554', '304780', '417955', '909', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('555', '555', '831640', '961194', '917', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('556', '556', '150662', '623325', '919', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('557', '557', '786845', '923730', '908', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('558', '558', '429001', '479776', '909', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('559', '559', '696765', '891980', '904', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('560', '560', '143526', '282781', '906', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('561', '561', '124263', '319524', '913', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('562', '562', '765317', '370449', '916', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('563', '563', '872405', '201495', '917', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('564', '564', '611653', '770351', '906', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('565', '565', '397003', '155317', '903', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('566', '566', '652518', '654001', '917', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('567', '567', '640775', '666132', '906', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('568', '568', '717000', '265090', '916', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('569', '569', '543945', '934317', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('570', '570', '712178', '452687', '908', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('571', '571', '784214', '799780', '908', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('572', '572', '595136', '982734', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('573', '573', '745248', '294837', '916', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('574', '574', '520200', '108100', '906', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('575', '575', '672172', '819131', '901', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('576', '576', '299525', '239879', '914', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('577', '577', '823951', '384209', '906', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('578', '578', '275371', '852382', '911', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('579', '579', '813366', '931572', '912', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('580', '580', '428609', '902029', '912', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('581', '581', '897133', '415238', '903', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('582', '582', '703701', '884434', '907', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('583', '583', '323803', '543438', '917', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('584', '584', '639523', '632808', '903', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('585', '585', '778688', '510153', '902', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('586', '586', '964589', '705244', '901', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('587', '587', '603759', '478671', '906', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('588', '588', '954757', '179934', '901', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('589', '589', '975239', '630123', '913', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('590', '590', '667703', '562300', '909', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('591', '591', '926418', '665965', '908', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('592', '592', '195663', '191769', '913', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('593', '593', '939066', '425205', '909', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('594', '594', '526679', '100196', '919', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('595', '595', '305628', '695474', '917', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('596', '596', '281033', '962743', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('597', '597', '516896', '596712', '913', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('598', '598', '304436', '197660', '907', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('599', '599', '848926', '470374', '907', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('600', '600', '663540', '395960', '908', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('601', '601', '387729', '814477', '908', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('602', '602', '444636', '768889', '903', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('603', '603', '266701', '445973', '915', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('604', '604', '199716', '969590', '914', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('605', '605', '772591', '509283', '907', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('606', '606', '452483', '345978', '918', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('607', '607', '611310', '113967', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('608', '608', '361641', '178834', '913', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('609', '609', '806685', '435613', '912', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('610', '610', '608975', '360776', '902', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('611', '611', '897788', '387412', '913', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('612', '612', '827520', '193623', '915', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('613', '613', '219609', '839139', '911', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('614', '614', '869806', '946285', '908', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('615', '615', '777444', '719412', '910', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('616', '616', '677301', '386413', '912', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('617', '617', '925211', '706760', '914', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('618', '618', '843328', '231065', '911', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('619', '619', '784442', '457166', '906', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('620', '620', '281210', '933773', '917', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('621', '621', '846233', '444187', '911', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('622', '622', '502143', '224743', '919', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('623', '623', '410544', '240284', '919', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('624', '624', '117763', '296781', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('625', '625', '646919', '656493', '909', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('626', '626', '970306', '179222', '914', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('627', '627', '865632', '996456', '902', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('628', '628', '369566', '878142', '904', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('629', '629', '983377', '834536', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('630', '630', '254068', '360475', '903', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('631', '631', '118689', '983689', '909', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('632', '632', '499811', '329528', '906', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('633', '633', '203825', '687172', '913', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('634', '634', '766924', '437616', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('635', '635', '332794', '871324', '906', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('636', '636', '671810', '438645', '908', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('637', '637', '984945', '782323', '901', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('638', '638', '879467', '744400', '915', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('639', '639', '438225', '284669', '904', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('640', '640', '506720', '966360', '904', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('641', '641', '874710', '617417', '903', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('642', '642', '145402', '594092', '903', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('643', '643', '990615', '692015', '901', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('644', '644', '785257', '854513', '904', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('645', '645', '654164', '339364', '915', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('646', '646', '224732', '605484', '909', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('647', '647', '581352', '288834', '910', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('648', '648', '952604', '169315', '906', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('649', '649', '689765', '856952', '914', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('650', '650', '833188', '264097', '915', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('651', '651', '682320', '449319', '918', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('652', '652', '827287', '268158', '912', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('653', '653', '211227', '184411', '904', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('654', '654', '421843', '665935', '906', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('655', '655', '579371', '131276', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('656', '656', '575680', '800506', '903', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('657', '657', '170238', '106904', '914', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('658', '658', '360788', '608185', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('659', '659', '650952', '275311', '910', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('660', '660', '955966', '314113', '918', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('661', '661', '516047', '349879', '908', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('662', '662', '179420', '882323', '903', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('663', '663', '640691', '427773', '914', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('664', '664', '986067', '527780', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('665', '665', '487941', '973660', '913', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('666', '666', '141742', '452083', '910', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('667', '667', '885886', '268647', '909', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('668', '668', '353295', '474937', '914', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('669', '669', '582206', '677193', '917', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('670', '670', '430244', '975709', '918', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('671', '671', '658024', '466383', '906', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('672', '672', '872522', '162719', '918', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('673', '673', '640563', '130443', '917', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('674', '674', '475675', '762942', '914', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('675', '675', '944470', '452042', '913', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('676', '676', '117514', '883059', '918', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('677', '677', '699370', '913822', '910', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('678', '678', '352102', '944210', '915', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('679', '679', '568958', '992923', '909', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('680', '680', '899952', '346409', '914', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('681', '681', '374683', '552800', '906', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('682', '682', '827118', '961302', '903', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('683', '683', '499086', '150908', '915', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('684', '684', '186186', '497250', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('685', '685', '817145', '850073', '903', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('686', '686', '701540', '945840', '907', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('687', '687', '138750', '863818', '910', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('688', '688', '996484', '139144', '918', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('689', '689', '962127', '961901', '902', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('690', '690', '183440', '641457', '904', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('691', '691', '346424', '785091', '910', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('692', '692', '931717', '617575', '916', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('693', '693', '301536', '468343', '910', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('694', '694', '185613', '761620', '914', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('695', '695', '845267', '677917', '907', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('696', '696', '254911', '332290', '904', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('697', '697', '451873', '542184', '915', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('698', '698', '138230', '254600', '908', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('699', '699', '567451', '293820', '903', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('700', '700', '340475', '215686', '904', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('701', '701', '599835', '726043', '907', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('702', '702', '428109', '686010', '917', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('703', '703', '365094', '903464', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('704', '704', '690879', '417748', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('705', '705', '966537', '204943', '914', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('706', '706', '894371', '187396', '914', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('707', '707', '945911', '405048', '918', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('708', '708', '134759', '596936', '903', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('709', '709', '125014', '375465', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('710', '710', '913786', '578300', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('711', '711', '588705', '479448', '903', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('712', '712', '539018', '941808', '914', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('713', '713', '104971', '534509', '904', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('714', '714', '787535', '903818', '904', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('715', '715', '734878', '661760', '909', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('716', '716', '306320', '746236', '901', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('717', '717', '367036', '752100', '903', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('718', '718', '394047', '392939', '901', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('719', '719', '897435', '322374', '913', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('720', '720', '108848', '700630', '917', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('721', '721', '254074', '261356', '919', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('722', '722', '822612', '148639', '915', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('723', '723', '929562', '510439', '903', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('724', '724', '616321', '807740', '914', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('725', '725', '499555', '251933', '917', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('726', '726', '219258', '669403', '907', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('727', '727', '643059', '142012', '906', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('728', '728', '406371', '930934', '902', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('729', '729', '512754', '458034', '909', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('730', '730', '861319', '983336', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('731', '731', '491754', '739929', '911', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('732', '732', '598814', '979817', '904', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('733', '733', '437508', '583791', '919', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('734', '734', '234787', '164813', '901', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('735', '735', '354452', '895663', '908', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('736', '736', '576586', '357765', '903', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('737', '737', '873014', '907902', '916', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('738', '738', '898244', '623773', '909', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('739', '739', '309142', '133452', '916', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('740', '740', '191454', '624853', '916', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('741', '741', '741535', '333872', '904', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('742', '742', '943583', '734641', '914', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('743', '743', '892172', '581951', '919', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('744', '744', '690948', '208014', '908', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('745', '745', '565382', '330993', '902', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('746', '746', '459188', '325852', '913', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('747', '747', '392938', '687308', '916', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('748', '748', '761209', '470040', '908', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('749', '749', '669743', '115891', '903', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('750', '750', '303336', '442384', '919', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('751', '751', '853904', '342362', '906', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('752', '752', '520632', '537176', '911', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('753', '753', '968463', '761926', '907', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('754', '754', '604576', '491815', '902', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('755', '755', '227891', '134689', '906', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('756', '756', '612818', '588011', '902', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('757', '757', '678965', '677727', '911', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('758', '758', '404105', '677623', '902', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('759', '759', '100992', '820055', '906', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('760', '760', '114896', '950200', '906', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('761', '761', '174264', '301943', '919', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('762', '762', '335908', '820270', '907', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('763', '763', '678880', '948682', '906', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('764', '764', '450233', '626875', '903', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('765', '765', '263196', '446735', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('766', '766', '348959', '624157', '915', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('767', '767', '813834', '267036', '916', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('768', '768', '196382', '406383', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('769', '769', '910902', '272290', '906', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('770', '770', '351929', '438003', '908', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('771', '771', '724108', '795989', '915', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('772', '772', '558495', '292348', '904', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('773', '773', '555083', '464839', '906', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('774', '774', '258100', '205355', '918', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('775', '775', '700211', '444032', '901', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('776', '776', '607427', '671227', '912', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('777', '777', '410235', '196601', '917', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('778', '778', '278838', '177931', '908', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('779', '779', '490870', '111368', '906', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('780', '780', '465296', '898274', '915', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('781', '781', '289520', '657932', '919', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('782', '782', '858835', '493189', '917', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('783', '783', '577780', '182545', '916', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('784', '784', '607854', '535429', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('785', '785', '763327', '364432', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('786', '786', '253688', '395937', '909', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('787', '787', '355379', '832078', '903', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('788', '788', '875530', '452178', '902', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('789', '789', '225886', '563681', '907', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('790', '790', '844407', '405019', '909', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('791', '791', '504129', '314613', '915', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('792', '792', '717604', '481291', '908', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('793', '793', '287112', '445704', '906', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('794', '794', '458345', '168770', '912', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('795', '795', '696585', '726015', '904', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('796', '796', '210604', '980826', '913', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('797', '797', '209311', '185592', '906', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('798', '798', '367778', '935131', '914', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('799', '799', '854941', '562200', '917', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('800', '800', '615608', '953805', '904', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('801', '801', '357913', '979900', '907', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('802', '802', '463850', '986136', '919', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('803', '803', '531558', '859261', '913', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('804', '804', '385627', '355801', '912', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('805', '805', '677154', '598714', '918', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('806', '806', '480886', '734193', '914', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('807', '807', '718873', '504564', '918', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('808', '808', '527823', '481617', '915', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('809', '809', '124438', '816177', '902', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('810', '810', '392636', '684171', '913', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('811', '811', '142202', '302151', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('812', '812', '300549', '454016', '904', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('813', '813', '692757', '652994', '908', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('814', '814', '212462', '533856', '901', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('815', '815', '654926', '278573', '902', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('816', '816', '827098', '988202', '913', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('817', '817', '153075', '288779', '913', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('818', '818', '286174', '735253', '905', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('819', '819', '344075', '192659', '907', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('820', '820', '894675', '584165', '904', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('821', '821', '871720', '357440', '901', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('822', '822', '652616', '664793', '915', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('823', '823', '551442', '508073', '917', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('824', '824', '830683', '825176', '916', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('825', '825', '965040', '618917', '913', '2019-01-11 16:41:59', '2019-01-11 16:41:59');
INSERT INTO `tm_admin_extra_info` VALUES ('826', '826', '335711', '107004', '908', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('827', '827', '444088', '699281', '914', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('828', '828', '618214', '165633', '911', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('829', '829', '512818', '530696', '915', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('830', '830', '766544', '547043', '914', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('831', '831', '998325', '858980', '905', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('832', '832', '669729', '742119', '904', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('833', '833', '846885', '479609', '906', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('834', '834', '551792', '969340', '903', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('835', '835', '998086', '145450', '905', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('836', '836', '834587', '904123', '910', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('837', '837', '749967', '766156', '902', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('838', '838', '462324', '516274', '913', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('839', '839', '465721', '101368', '910', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('840', '840', '382855', '882124', '912', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('841', '841', '558747', '649781', '906', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('842', '842', '953916', '998097', '906', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('843', '843', '822469', '324083', '913', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('844', '844', '377334', '290730', '901', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('845', '845', '506022', '173510', '917', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('846', '846', '767090', '469807', '907', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('847', '847', '530703', '170728', '918', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('848', '848', '472237', '260415', '915', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('849', '849', '603899', '222883', '919', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('850', '850', '956734', '844170', '904', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('851', '851', '941943', '877043', '910', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('852', '852', '449927', '827082', '908', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('853', '853', '405114', '429325', '908', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('854', '854', '964741', '253784', '905', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('855', '855', '776693', '917564', '911', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('856', '856', '646457', '343927', '902', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('857', '857', '869426', '572023', '910', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('858', '858', '744465', '151961', '916', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('859', '859', '371499', '508997', '912', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('860', '860', '799750', '928278', '909', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('861', '861', '702272', '721888', '913', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('862', '862', '875558', '522982', '914', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('863', '863', '541215', '411413', '918', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('864', '864', '544355', '752347', '910', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('865', '865', '514197', '517570', '919', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('866', '866', '548379', '304063', '905', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('867', '867', '868049', '560099', '919', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('868', '868', '527120', '934501', '907', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('869', '869', '540029', '640192', '911', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('870', '870', '353412', '147430', '915', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('871', '871', '492348', '235898', '911', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('872', '872', '926076', '395744', '910', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('873', '873', '700445', '811908', '906', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('874', '874', '179475', '926959', '917', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('875', '875', '586134', '567801', '906', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('876', '876', '141115', '681855', '915', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('877', '877', '277678', '609568', '904', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('878', '878', '280290', '931244', '906', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('879', '879', '586056', '350053', '908', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('880', '880', '736100', '749040', '919', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('881', '881', '357059', '162623', '918', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('882', '882', '808432', '316168', '919', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('883', '883', '756544', '320611', '916', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('884', '884', '409113', '938878', '902', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('885', '885', '689248', '905694', '901', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('886', '886', '496839', '929142', '909', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('887', '887', '521015', '464354', '910', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('888', '888', '922276', '900282', '905', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('889', '889', '529387', '165833', '915', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('890', '890', '188732', '274488', '917', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('891', '891', '347434', '421640', '902', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('892', '892', '135667', '215346', '918', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('893', '893', '203880', '563515', '910', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('894', '894', '670812', '490121', '915', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('895', '895', '294686', '710458', '915', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('896', '896', '139194', '700823', '914', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('897', '897', '252210', '279382', '901', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('898', '898', '118288', '446667', '919', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('899', '899', '322112', '857248', '916', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('900', '900', '640433', '963605', '916', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('901', '901', '947882', '444545', '917', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('902', '902', '706633', '871147', '916', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('903', '903', '791933', '674789', '908', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('904', '904', '918732', '172343', '903', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('905', '905', '734945', '496082', '913', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('906', '906', '701464', '682359', '901', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('907', '907', '765781', '384734', '911', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('908', '908', '655923', '702925', '902', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('909', '909', '955065', '636602', '917', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('910', '910', '999815', '412929', '910', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('911', '911', '649744', '197397', '907', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('912', '912', '250815', '481231', '910', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('913', '913', '787673', '344123', '904', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('914', '914', '998080', '497621', '913', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('915', '915', '344377', '391021', '902', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('916', '916', '553170', '286885', '911', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('917', '917', '224081', '981883', '904', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('918', '918', '995941', '520386', '917', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('919', '919', '113056', '658962', '916', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('920', '920', '931742', '182640', '908', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('921', '921', '654419', '901335', '904', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('922', '922', '651585', '553203', '908', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('923', '923', '894032', '824431', '912', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('924', '924', '188246', '360517', '914', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('925', '925', '711343', '119287', '915', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('926', '926', '597846', '893589', '917', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('927', '927', '373013', '989892', '907', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('928', '928', '827559', '499701', '907', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('929', '929', '331425', '249970', '909', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('930', '930', '648091', '728011', '902', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('931', '931', '146858', '770753', '901', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('932', '932', '288674', '974323', '911', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('933', '933', '383349', '145046', '915', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('934', '934', '656386', '570702', '902', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('935', '935', '854809', '104923', '914', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('936', '936', '185986', '782112', '916', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('937', '937', '845255', '379663', '902', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('938', '938', '161764', '427183', '918', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('939', '939', '117155', '153630', '902', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('940', '940', '443085', '790813', '901', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('941', '941', '587656', '889833', '912', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('942', '942', '157149', '256599', '911', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('943', '943', '129868', '262918', '916', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('944', '944', '294109', '330984', '916', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('945', '945', '611715', '749526', '917', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('946', '946', '690260', '767677', '909', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('947', '947', '298184', '181220', '906', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('948', '948', '851572', '506439', '916', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('949', '949', '343208', '140953', '902', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('950', '950', '175151', '671729', '902', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('951', '951', '159311', '529484', '916', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('952', '952', '813836', '670461', '905', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('953', '953', '969973', '878925', '905', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('954', '954', '156889', '795711', '916', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('955', '955', '414043', '273248', '901', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('956', '956', '716376', '643845', '910', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('957', '957', '662055', '838799', '914', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('958', '958', '525124', '436429', '903', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('959', '959', '570412', '436867', '913', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('960', '960', '724259', '846988', '915', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('961', '961', '373481', '462397', '915', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('962', '962', '871196', '877404', '911', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('963', '963', '462252', '262060', '916', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('964', '964', '396263', '842595', '915', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('965', '965', '966837', '399576', '909', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('966', '966', '707092', '122946', '918', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('967', '967', '714841', '586202', '901', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('968', '968', '106451', '789562', '903', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('969', '969', '326993', '619471', '911', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('970', '970', '706305', '243640', '916', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('971', '971', '138314', '133559', '904', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('972', '972', '681427', '581928', '911', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('973', '973', '130817', '803915', '911', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('974', '974', '659984', '358433', '917', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('975', '975', '903580', '368165', '912', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('976', '976', '454174', '937456', '912', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('977', '977', '209388', '891161', '917', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('978', '978', '690620', '528652', '911', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('979', '979', '362216', '111989', '903', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('980', '980', '761806', '323942', '909', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('981', '981', '389757', '482947', '905', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('982', '982', '566974', '358052', '901', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('983', '983', '221338', '638511', '916', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('984', '984', '755249', '168068', '917', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('985', '985', '140090', '946569', '907', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('986', '986', '233273', '848094', '906', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('987', '987', '311354', '958243', '907', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('988', '988', '435516', '803652', '919', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('989', '989', '459022', '494648', '915', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('990', '990', '180193', '434351', '918', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('991', '991', '995413', '257468', '914', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('992', '992', '236478', '664920', '918', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('993', '993', '997062', '337149', '905', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('994', '994', '862549', '884996', '919', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('995', '995', '645540', '735945', '913', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('996', '996', '516316', '881835', '904', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('997', '997', '777790', '398717', '903', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('998', '998', '321742', '985659', '915', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('999', '999', '789249', '424086', '913', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_admin_extra_info` VALUES ('1000', '1000', '457997', '282865', '911', '2019-01-11 16:42:00', '2019-01-11 16:42:00');

-- ----------------------------
-- Table structure for `tm_reason`
-- ----------------------------
DROP TABLE IF EXISTS `tm_reason`;
CREATE TABLE `tm_reason` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '撥打理由 ID',
  `content` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '撥打理由 內容描述',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of tm_reason
-- ----------------------------
INSERT INTO `tm_reason` VALUES ('1', '陌生开发', '2019-01-11 16:42:00', '2019-01-11 16:42:00', null);
INSERT INTO `tm_reason` VALUES ('2', '事件通知', '2019-01-11 16:42:00', '2019-01-11 16:42:00', null);
INSERT INTO `tm_reason` VALUES ('3', '信息核实', '2019-01-11 16:42:00', '2019-01-11 16:42:00', null);
INSERT INTO `tm_reason` VALUES ('4', '活动推广', '2019-01-11 16:42:00', '2019-01-11 16:42:00', null);
INSERT INTO `tm_reason` VALUES ('5', '关怀拜访', '2019-01-11 16:42:00', '2019-01-11 16:42:00', null);
INSERT INTO `tm_reason` VALUES ('6', '会员要求', '2019-01-11 16:42:00', '2019-01-11 16:42:00', null);

-- ----------------------------
-- Table structure for `tm_result`
-- ----------------------------
DROP TABLE IF EXISTS `tm_result`;
CREATE TABLE `tm_result` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '撥打結果 ID',
  `content` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '撥打結果 內容描述',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of tm_result
-- ----------------------------
INSERT INTO `tm_result` VALUES ('1', '无效-空号', '2019-01-11 16:42:00', '2019-01-11 16:42:00', null);
INSERT INTO `tm_result` VALUES ('2', '无效-停机', '2019-01-11 16:42:00', '2019-01-11 16:42:00', null);
INSERT INTO `tm_result` VALUES ('3', '无效-关机', '2019-01-11 16:42:00', '2019-01-11 16:42:00', null);
INSERT INTO `tm_result` VALUES ('4', '无效-占线', '2019-01-11 16:42:00', '2019-01-11 16:42:00', null);
INSERT INTO `tm_result` VALUES ('5', '无效-无法接通', '2019-01-11 16:42:00', '2019-01-11 16:42:00', null);
INSERT INTO `tm_result` VALUES ('6', '正常-信號不佳挂线', '2019-01-11 16:42:00', '2019-01-11 16:42:00', null);
INSERT INTO `tm_result` VALUES ('7', '正常-聽到來歷挂线', '2019-01-11 16:42:00', '2019-01-11 16:42:00', null);
INSERT INTO `tm_result` VALUES ('8', '正常-稍晚再拨', '2019-01-11 16:42:00', '2019-01-11 16:42:00', null);
INSERT INTO `tm_result` VALUES ('9', '正常-查无此人', '2019-01-11 16:42:00', '2019-01-11 16:42:00', null);
INSERT INTO `tm_result` VALUES ('10', '正常-完成通話目的', '2019-01-11 16:42:00', '2019-01-11 16:42:00', null);
INSERT INTO `tm_result` VALUES ('11', '正常-未完成需回撥', '2019-01-11 16:42:00', '2019-01-11 16:42:00', null);

-- ----------------------------
-- Table structure for `tm_task`
-- ----------------------------
DROP TABLE IF EXISTS `tm_task`;
CREATE TABLE `tm_task` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `promoter_id` int(10) unsigned NOT NULL COMMENT '負責專員的 ID',
  `type` int(10) unsigned NOT NULL DEFAULT 0 COMMENT '任務類型：1電銷 2電維',
  `count` int(10) unsigned NOT NULL COMMENT '電話總數',
  `completed` int(10) unsigned NOT NULL COMMENT '完成数,计算完成率,只接通纍計',
  `status` tinyint(3) unsigned NOT NULL DEFAULT 0 COMMENT '0禁用, 1启用',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of tm_task
-- ----------------------------
INSERT INTO `tm_task` VALUES ('1', '67', '0', '10', '10', '1', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_task` VALUES ('2', '71', '0', '10', '0', '1', '2019-01-11 16:42:00', '2019-01-11 16:42:00');

-- ----------------------------
-- Table structure for `tm_task_telephone`
-- ----------------------------
DROP TABLE IF EXISTS `tm_task_telephone`;
CREATE TABLE `tm_task_telephone` (
  `telephone_id` int(10) unsigned NOT NULL COMMENT '電話 id',
  `promoter_id` int(10) unsigned NOT NULL COMMENT '指派專員 id，可修改',
  `task_id` int(10) unsigned DEFAULT NULL COMMENT '任務 id',
  `start_call` datetime DEFAULT NULL COMMENT '任務第一次的開始時間，不管幾次',
  `end_call` datetime DEFAULT NULL COMMENT '任務最後一次的結束時間，不管幾次',
  `status` tinyint(3) unsigned NOT NULL DEFAULT 1 COMMENT '0 隱藏,1 顯示',
  `duration` int(10) unsigned NOT NULL DEFAULT 0 COMMENT '任務累計總時長，不分次數，單位秒',
  `sms_id` int(11) NOT NULL DEFAULT 0 COMMENT '當前任務短信 id',
  PRIMARY KEY (`telephone_id`,`promoter_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of tm_task_telephone
-- ----------------------------
INSERT INTO `tm_task_telephone` VALUES ('1', '67', '1', '2019-01-11 16:40:00', '2019-01-11 16:42:00', '1', '2', '1');
INSERT INTO `tm_task_telephone` VALUES ('2', '67', '1', '2019-01-11 16:40:00', '2019-01-11 16:42:00', '1', '2', '0');
INSERT INTO `tm_task_telephone` VALUES ('3', '67', '1', '2019-01-11 16:40:00', '2019-01-11 16:42:00', '1', '2', '0');
INSERT INTO `tm_task_telephone` VALUES ('4', '67', '1', '2019-01-11 16:40:00', '2019-01-11 16:42:00', '1', '2', '0');
INSERT INTO `tm_task_telephone` VALUES ('5', '67', '1', '2019-01-11 16:40:00', '2019-01-11 16:42:00', '1', '2', '1');
INSERT INTO `tm_task_telephone` VALUES ('6', '67', '1', '2019-01-11 16:40:00', '2019-01-11 16:42:00', '1', '2', '0');
INSERT INTO `tm_task_telephone` VALUES ('7', '67', '1', '2019-01-11 16:40:00', '2019-01-11 16:42:00', '1', '2', '0');
INSERT INTO `tm_task_telephone` VALUES ('8', '67', '1', '2019-01-11 16:40:00', '2019-01-11 16:42:00', '1', '2', '0');
INSERT INTO `tm_task_telephone` VALUES ('9', '67', '1', '2019-01-11 16:40:00', '2019-01-11 16:42:00', '1', '2', '0');
INSERT INTO `tm_task_telephone` VALUES ('10', '67', '1', '2019-01-11 16:40:00', '2019-01-11 16:42:00', '1', '2', '1');

-- ----------------------------
-- Table structure for `tm_telephone`
-- ----------------------------
DROP TABLE IF EXISTS `tm_telephone`;
CREATE TABLE `tm_telephone` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '電話ID',
  `upload_id` int(10) unsigned NOT NULL COMMENT '上傳的 id',
  `start_call` datetime DEFAULT NULL COMMENT '第一次撥號的開始時間，不管幾次撥號',
  `last_call` datetime DEFAULT NULL COMMENT '最後一次撥號的結束時間，不管幾次撥號',
  `duration` int(10) unsigned NOT NULL DEFAULT 0 COMMENT '累計通話總時長，不分次數，單位秒',
  `phone` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '電話號碼加密',
  `status` tinyint(3) unsigned NOT NULL DEFAULT 1 COMMENT '0禁用,1启用,2其他',
  `remark` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '為了之後轉移到別平台使用的禁用訊息',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL COMMENT '無效|空號',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of tm_telephone
-- ----------------------------
INSERT INTO `tm_telephone` VALUES ('1', '1', '2019-01-11 16:40:00', '2019-01-11 16:42:00', '2', 'u7pkPB4bb3sPOSdEa7cu3Q==', '1', null, '2019-01-11 16:42:00', '2019-01-11 16:42:00', null);
INSERT INTO `tm_telephone` VALUES ('2', '1', '2019-01-11 16:40:00', '2019-01-11 16:42:00', '2', 'VWDmy2bEex3B8awdD0/X2w==', '1', null, '2019-01-11 16:42:00', '2019-01-11 16:42:00', null);
INSERT INTO `tm_telephone` VALUES ('3', '1', '2019-01-11 16:40:00', '2019-01-11 16:42:00', '2', '1gW2+CxyTNUx1BnuPAI1IQ==', '1', null, '2019-01-11 16:42:00', '2019-01-11 16:42:00', null);
INSERT INTO `tm_telephone` VALUES ('4', '1', '2019-01-11 16:40:00', '2019-01-11 16:42:00', '2', '1c+MtFZXX+417liOjASf7g==', '1', null, '2019-01-11 16:42:00', '2019-01-11 16:42:00', null);
INSERT INTO `tm_telephone` VALUES ('5', '1', '2019-01-11 16:40:00', '2019-01-11 16:42:00', '2', 'mA3NnN4S3S7Y4pcszL70fw==', '1', null, '2019-01-11 16:42:00', '2019-01-11 16:42:00', null);
INSERT INTO `tm_telephone` VALUES ('6', '2', '2019-01-11 16:40:00', '2019-01-11 16:42:00', '2', '0ltyuSGPQxZuOJBJPmVaBw==', '1', null, '2019-01-11 16:42:00', '2019-01-11 16:42:00', null);
INSERT INTO `tm_telephone` VALUES ('7', '2', '2019-01-11 16:40:00', '2019-01-11 16:42:00', '2', '7dvoJE1d95D7ndqpwD7B3g==', '1', null, '2019-01-11 16:42:00', '2019-01-11 16:42:00', null);
INSERT INTO `tm_telephone` VALUES ('8', '2', '2019-01-11 16:40:00', '2019-01-11 16:42:00', '2', 'CHW2js7nc5yOMOMJ2bkdGA==', '1', null, '2019-01-11 16:42:00', '2019-01-11 16:42:00', null);
INSERT INTO `tm_telephone` VALUES ('9', '2', '2019-01-11 16:40:00', '2019-01-11 16:42:00', '2', 'c2QgCNwMOk4KPO4SPbryRg==', '1', null, '2019-01-11 16:42:00', '2019-01-11 16:42:00', null);
INSERT INTO `tm_telephone` VALUES ('10', '2', '2019-01-11 16:40:00', '2019-01-11 16:42:00', '2', 'fUs96OKRdKF9Bmv1mC4aDA==', '1', null, '2019-01-11 16:42:00', '2019-01-11 16:42:00', null);
INSERT INTO `tm_telephone` VALUES ('11', '3', null, null, '0', 'uVypMy91XkHhbcR4K2nJWA==', '1', null, '2019-01-11 16:42:00', '2019-01-11 16:42:00', null);
INSERT INTO `tm_telephone` VALUES ('12', '3', null, null, '0', 'CnDg32qxXVUOZ04uE/nC5A==', '1', null, '2019-01-11 16:42:00', '2019-01-11 16:42:00', null);
INSERT INTO `tm_telephone` VALUES ('13', '3', null, null, '0', 'vTmIibkXITaz7WkgnnwF+g==', '1', null, '2019-01-11 16:42:00', '2019-01-11 16:42:00', null);
INSERT INTO `tm_telephone` VALUES ('14', '3', null, null, '0', '83ggyh56UEA4UR+KmYP+8Q==', '1', null, '2019-01-11 16:42:00', '2019-01-11 16:42:00', null);
INSERT INTO `tm_telephone` VALUES ('15', '3', null, null, '0', 'GcQIN9fP4qXVsCppDdrtDg==', '1', null, '2019-01-11 16:42:00', '2019-01-11 16:42:00', null);
INSERT INTO `tm_telephone` VALUES ('16', '4', null, null, '0', 'PGAvm51gSi2vTd6d61DPbQ==', '1', null, '2019-01-11 16:42:00', '2019-01-11 16:42:00', null);
INSERT INTO `tm_telephone` VALUES ('17', '4', null, null, '0', 'nhHsqCzMjTn8/HJoV08Buw==', '1', null, '2019-01-11 16:42:00', '2019-01-11 16:42:00', null);
INSERT INTO `tm_telephone` VALUES ('18', '4', null, null, '0', 'KXUu6pS6VWodkSxgbDRpAQ==', '1', null, '2019-01-11 16:42:00', '2019-01-11 16:42:00', null);
INSERT INTO `tm_telephone` VALUES ('19', '4', null, null, '0', 'pxYh2tUwh1H+n539Qkprhg==', '1', null, '2019-01-11 16:42:00', '2019-01-11 16:42:00', null);
INSERT INTO `tm_telephone` VALUES ('20', '4', null, null, '0', 'lfZ/YDJrHKsPXd7YpENoeQ==', '1', null, '2019-01-11 16:42:00', '2019-01-11 16:42:00', null);

-- ----------------------------
-- Table structure for `tm_telephone_admin_relation`
-- ----------------------------
DROP TABLE IF EXISTS `tm_telephone_admin_relation`;
CREATE TABLE `tm_telephone_admin_relation` (
  `telephone_id` int(10) unsigned NOT NULL COMMENT '電話ID',
  `promoter_id` int(10) unsigned NOT NULL COMMENT 'ADMIN_ID',
  PRIMARY KEY (`telephone_id`),
  KEY `tm_telephone_admin_relation_promoter_id_index` (`promoter_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of tm_telephone_admin_relation
-- ----------------------------

-- ----------------------------
-- Table structure for `tm_telephone_member_relation`
-- ----------------------------
DROP TABLE IF EXISTS `tm_telephone_member_relation`;
CREATE TABLE `tm_telephone_member_relation` (
  `member_id` int(10) unsigned NOT NULL COMMENT 'ref.member_info用戶ID',
  `telephone_id` int(10) unsigned NOT NULL COMMENT 'ref.telephonn電話ID',
  PRIMARY KEY (`member_id`),
  KEY `tm_telephone_member_relation_telephone_id_index` (`telephone_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of tm_telephone_member_relation
-- ----------------------------
INSERT INTO `tm_telephone_member_relation` VALUES ('1', '1');
INSERT INTO `tm_telephone_member_relation` VALUES ('2', '2');
INSERT INTO `tm_telephone_member_relation` VALUES ('3', '3');
INSERT INTO `tm_telephone_member_relation` VALUES ('4', '4');
INSERT INTO `tm_telephone_member_relation` VALUES ('5', '5');
INSERT INTO `tm_telephone_member_relation` VALUES ('6', '6');
INSERT INTO `tm_telephone_member_relation` VALUES ('7', '7');
INSERT INTO `tm_telephone_member_relation` VALUES ('8', '8');
INSERT INTO `tm_telephone_member_relation` VALUES ('9', '9');
INSERT INTO `tm_telephone_member_relation` VALUES ('10', '10');

-- ----------------------------
-- Table structure for `tm_telephone_other_info`
-- ----------------------------
DROP TABLE IF EXISTS `tm_telephone_other_info`;
CREATE TABLE `tm_telephone_other_info` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `telephone_id` int(10) unsigned NOT NULL COMMENT '電話 id',
  `upload_id` int(10) unsigned NOT NULL COMMENT '上傳 id',
  `name` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '姓名',
  `source` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '來源網址',
  `province` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '省份',
  `deposit` int(10) unsigned DEFAULT NULL COMMENT '前平台存款',
  `withdrawal` int(10) unsigned DEFAULT NULL COMMENT '前平台提款',
  `bet_amount` int(10) unsigned DEFAULT NULL COMMENT '前平台碼量',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of tm_telephone_other_info
-- ----------------------------
INSERT INTO `tm_telephone_other_info` VALUES ('1', '1', '1', '姓名', 'http://www.baidu.com', null, null, null, null);
INSERT INTO `tm_telephone_other_info` VALUES ('2', '2', '1', '姓名', 'http://www.baidu.com', null, null, null, null);
INSERT INTO `tm_telephone_other_info` VALUES ('3', '3', '1', '姓名', 'http://www.baidu.com', null, null, null, null);
INSERT INTO `tm_telephone_other_info` VALUES ('4', '4', '1', '姓名', 'http://www.baidu.com', null, null, null, null);
INSERT INTO `tm_telephone_other_info` VALUES ('5', '5', '1', '姓名', 'http://www.baidu.com', null, null, null, null);
INSERT INTO `tm_telephone_other_info` VALUES ('6', '6', '2', '姓名', 'http://www.baidu.com', null, null, null, null);
INSERT INTO `tm_telephone_other_info` VALUES ('7', '7', '2', '姓名', 'http://www.baidu.com', null, null, null, null);
INSERT INTO `tm_telephone_other_info` VALUES ('8', '8', '2', '姓名', 'http://www.baidu.com', null, null, null, null);
INSERT INTO `tm_telephone_other_info` VALUES ('9', '9', '2', '姓名', 'http://www.baidu.com', null, null, null, null);
INSERT INTO `tm_telephone_other_info` VALUES ('10', '10', '2', '姓名', 'http://www.baidu.com', null, null, null, null);
INSERT INTO `tm_telephone_other_info` VALUES ('11', '11', '3', '姓名', 'http://www.baidu.com', null, null, null, null);
INSERT INTO `tm_telephone_other_info` VALUES ('12', '12', '3', '姓名', 'http://www.baidu.com', null, null, null, null);
INSERT INTO `tm_telephone_other_info` VALUES ('13', '13', '3', '姓名', 'http://www.baidu.com', null, null, null, null);
INSERT INTO `tm_telephone_other_info` VALUES ('14', '14', '3', '姓名', 'http://www.baidu.com', null, null, null, null);
INSERT INTO `tm_telephone_other_info` VALUES ('15', '15', '3', '姓名', 'http://www.baidu.com', null, null, null, null);
INSERT INTO `tm_telephone_other_info` VALUES ('16', '16', '4', '姓名', 'http://www.baidu.com', null, null, null, null);
INSERT INTO `tm_telephone_other_info` VALUES ('17', '17', '4', '姓名', 'http://www.baidu.com', null, null, null, null);
INSERT INTO `tm_telephone_other_info` VALUES ('18', '18', '4', '姓名', 'http://www.baidu.com', null, null, null, null);
INSERT INTO `tm_telephone_other_info` VALUES ('19', '19', '4', '姓名', 'http://www.baidu.com', null, null, null, null);
INSERT INTO `tm_telephone_other_info` VALUES ('20', '20', '4', '姓名', 'http://www.baidu.com', null, null, null, null);

-- ----------------------------
-- Table structure for `tm_telephone_upload_log`
-- ----------------------------
DROP TABLE IF EXISTS `tm_telephone_upload_log`;
CREATE TABLE `tm_telephone_upload_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `admin_id` int(10) unsigned NOT NULL COMMENT '當前上傳者 id',
  `distinct_member` int(10) unsigned NOT NULL COMMENT '重複會員',
  `distinct_number` int(10) unsigned NOT NULL COMMENT '重複號碼',
  `invalid` int(10) unsigned NOT NULL COMMENT '無效號碼',
  `succeed` int(10) unsigned NOT NULL COMMENT '成功數',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of tm_telephone_upload_log
-- ----------------------------
INSERT INTO `tm_telephone_upload_log` VALUES ('1', '67', '0', '0', '0', '5', '2019-01-11 16:42:00');
INSERT INTO `tm_telephone_upload_log` VALUES ('2', '67', '0', '0', '0', '5', '2019-01-11 16:42:00');
INSERT INTO `tm_telephone_upload_log` VALUES ('3', '67', '0', '0', '0', '5', '2019-01-11 16:42:00');
INSERT INTO `tm_telephone_upload_log` VALUES ('4', '67', '0', '0', '0', '5', '2019-01-11 16:42:00');

-- ----------------------------
-- Table structure for `tm_voip_log`
-- ----------------------------
DROP TABLE IF EXISTS `tm_voip_log`;
CREATE TABLE `tm_voip_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `admin_id` int(10) unsigned NOT NULL COMMENT '誰撥打這次電話',
  `telephone_id` int(10) unsigned NOT NULL COMMENT '這支電話的 id',
  `task_id` int(10) unsigned NOT NULL COMMENT '所屬任務 id',
  `start_call` datetime DEFAULT NULL COMMENT '電話撥打時間',
  `end_call` datetime DEFAULT NULL COMMENT '電話結束時間',
  `duration` int(10) unsigned NOT NULL COMMENT '通話時長',
  `cost` double(12,2) NOT NULL DEFAULT 0.00 COMMENT '通话费用',
  `voip_provider_id` int(10) unsigned DEFAULT NULL COMMENT 'voip 廠商ID',
  `voip_sn` int(11) DEFAULT NULL COMMENT 'voip 對應第三方的流水號',
  `audio_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'voip 錄音文件地址',
  `reason_id` int(10) unsigned NOT NULL COMMENT '這次撥打的原因',
  `result_id` int(10) unsigned NOT NULL COMMENT '這次撥打的結果',
  `remark` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '備註',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of tm_voip_log
-- ----------------------------
INSERT INTO `tm_voip_log` VALUES ('1', '67', '1', '1', '2019-01-11 16:40:00', '2019-01-11 16:42:00', '2', '1.23', '1', '20010426', '/dvdau/ph/wav/20181213/20181213_114606_22_1544672796858_912.wav', '1', '5', '測試', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_voip_log` VALUES ('2', '67', '2', '1', '2019-01-11 16:40:00', '2019-01-11 16:42:00', '2', '1.23', '1', '20010426', '/dvdau/ph/wav/20181213/20181213_114606_22_1544672796858_912.wav', '1', '5', '測試', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_voip_log` VALUES ('3', '67', '3', '1', '2019-01-11 16:40:00', '2019-01-11 16:42:00', '2', '1.23', '1', '20010426', '/dvdau/ph/wav/20181213/20181213_114606_22_1544672796858_912.wav', '1', '5', '測試', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_voip_log` VALUES ('4', '67', '4', '1', '2019-01-11 16:40:00', '2019-01-11 16:42:00', '2', '1.23', '1', '20010426', '/dvdau/ph/wav/20181213/20181213_114606_22_1544672796858_912.wav', '1', '5', '測試', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_voip_log` VALUES ('5', '67', '5', '1', '2019-01-11 16:40:00', '2019-01-11 16:42:00', '2', '1.23', '1', '20010426', '/dvdau/ph/wav/20181213/20181213_114606_22_1544672796858_912.wav', '1', '5', '測試', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_voip_log` VALUES ('6', '67', '6', '1', '2019-01-11 16:40:00', '2019-01-11 16:42:00', '2', '1.23', '1', '20010426', '/dvdau/ph/wav/20181213/20181213_114606_22_1544672796858_912.wav', '1', '5', '測試', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_voip_log` VALUES ('7', '67', '7', '1', '2019-01-11 16:40:00', '2019-01-11 16:42:00', '2', '1.23', '1', '20010426', '/dvdau/ph/wav/20181213/20181213_114606_22_1544672796858_912.wav', '1', '5', '測試', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_voip_log` VALUES ('8', '67', '8', '1', '2019-01-11 16:40:00', '2019-01-11 16:42:00', '2', '1.23', '1', '20010426', '/dvdau/ph/wav/20181213/20181213_114606_22_1544672796858_912.wav', '1', '5', '測試', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_voip_log` VALUES ('9', '67', '9', '1', '2019-01-11 16:40:00', '2019-01-11 16:42:00', '2', '1.23', '1', '20010426', '/dvdau/ph/wav/20181213/20181213_114606_22_1544672796858_912.wav', '1', '5', '測試', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_voip_log` VALUES ('10', '67', '10', '1', '2019-01-11 16:40:00', '2019-01-11 16:42:00', '2', '1.23', '1', '20010426', '/dvdau/ph/wav/20181213/20181213_114606_22_1544672796858_912.wav', '1', '5', '測試', '2019-01-11 16:42:00', '2019-01-11 16:42:00');

-- ----------------------------
-- Table structure for `tm_voip_log_inspection`
-- ----------------------------
DROP TABLE IF EXISTS `tm_voip_log_inspection`;
CREATE TABLE `tm_voip_log_inspection` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `voip_log_id` int(10) unsigned NOT NULL COMMENT 'voip 的 id',
  `admin_id` int(11) NOT NULL COMMENT '紀錄填寫人',
  `content` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '稽查的感想',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of tm_voip_log_inspection
-- ----------------------------
INSERT INTO `tm_voip_log_inspection` VALUES ('1', '1', '75', '測試-稽查內容', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_voip_log_inspection` VALUES ('2', '2', '75', '測試-稽查內容', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_voip_log_inspection` VALUES ('3', '3', '75', '測試-稽查內容', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_voip_log_inspection` VALUES ('4', '4', '75', '測試-稽查內容', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_voip_log_inspection` VALUES ('5', '5', '75', '測試-稽查內容', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_voip_log_inspection` VALUES ('6', '6', '75', '測試-稽查內容', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_voip_log_inspection` VALUES ('7', '7', '75', '測試-稽查內容', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_voip_log_inspection` VALUES ('8', '8', '75', '測試-稽查內容', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_voip_log_inspection` VALUES ('9', '9', '75', '測試-稽查內容', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_voip_log_inspection` VALUES ('10', '10', '75', '測試-稽查內容', '2019-01-11 16:42:00', '2019-01-11 16:42:00');

-- ----------------------------
-- Table structure for `tm_voip_log_tm_task_relation`
-- ----------------------------
DROP TABLE IF EXISTS `tm_voip_log_tm_task_relation`;
CREATE TABLE `tm_voip_log_tm_task_relation` (
  `log_id` int(10) unsigned NOT NULL COMMENT '日誌ID',
  `task_id` int(10) unsigned NOT NULL COMMENT '任務ID',
  PRIMARY KEY (`log_id`),
  KEY `tm_voip_log_tm_task_relation_task_id_index` (`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of tm_voip_log_tm_task_relation
-- ----------------------------

-- ----------------------------
-- Table structure for `tm_voip_provider`
-- ----------------------------
DROP TABLE IF EXISTS `tm_voip_provider`;
CREATE TABLE `tm_voip_provider` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '廠商id',
  `name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '廠商名',
  `instance` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '对应计算费用的类实例',
  `local_ip` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '本地ip:7627',
  `remote_ip` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '遠端域名',
  `office_ip` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '办公室IP',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of tm_voip_provider
-- ----------------------------
INSERT INTO `tm_voip_provider` VALUES ('1', 'ph_ct', null, 'sip.topskywebcall.com:7627', '43.226.126.102', '180.232.66.154', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_voip_provider` VALUES ('2', 'ph_tz', null, 'sip01.topskywebcall.com:7627', '43.226.126.102', '43.231.229.178,127.0.0.1', '2019-01-11 16:42:00', '2019-01-11 16:42:00');
INSERT INTO `tm_voip_provider` VALUES ('3', 'tw_abc', null, 'sip02.topskywebcall.com:7627', '43.226.126.102', '2.2.2.2', '2019-01-11 16:42:00', '2019-01-11 16:42:00');

-- ----------------------------
-- Table structure for `white_list`
-- ----------------------------
DROP TABLE IF EXISTS `white_list`;
CREATE TABLE `white_list` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `status` tinyint(1) DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of white_list
-- ----------------------------
INSERT INTO `white_list` VALUES ('1', 'Test ip 0', '1', '180.232.66.154', null, null);
INSERT INTO `white_list` VALUES ('2', 'Test ip 1', '1', '127.0.0.1', null, null);

-- ----------------------------
-- View structure for `view_reg_ip`
-- ----------------------------
DROP VIEW IF EXISTS `view_reg_ip`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_reg_ip` AS select `reg_ip`.`ip_address` AS `ip_address`,`reg_ip`.`member_id` AS `member_id`,`reg_ip`.`status` AS `status`,max(`reg_ip`.`created_at`) AS `latest_created_time` from `reg_ip` where `reg_ip`.`status` = 'SUCCESS' group by `reg_ip`.`ip_address` order by `reg_ip`.`created_at` desc ;
